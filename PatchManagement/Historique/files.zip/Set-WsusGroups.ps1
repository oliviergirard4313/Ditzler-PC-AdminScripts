#Requires -Version 5.1
<#
.SYNOPSIS
    Konfiguriert WSUS-Computergruppen und Auto-Approval-Regeln
    entsprechend der neuen Patch-Strategie fuer Louis Ditzler AG.

.DESCRIPTION
    Neue Gruppen-Struktur (spiegelt AD-Gruppen CPT_SRV_WSUS-*):
    - Ditzler-AutoInstall-Wave1   : Patch-Installation Anfang Monat (2./3. Woche)
    - Ditzler-AutoInstall-Wave2   : Patch-Installation Ende Monat (4. Woche)
    - Ditzler-ManualInstall       : Nur Scan + Approve; Installation via Skript
    - Ditzler-NoPatch             : Nur Scan; KEINE Genehmigung, KEINE Installation
                                    (W2012R2 + alle DCs)
    - Ditzler-BasisConfig         : Basis-Policy fuer alle (WSUS-Zeiger)

    Approval-Regeln:
    - Wave1/Wave2: Critical + Security -> Auto-Approve
    - ManualInstall: KEINE Auto-Approval (manuell oder via Skript)
    - NoPatch: KEINE Regel -> nie genehmigt

    ACHTUNG: -WhatIf zeigt nur was gemacht wuerde, kein -Confirm noetig
             Produktiv ausfuehren erfordert explizites -Force

.PARAMETER Force
    Wirklich ausfuehren (ohne: nur Simulation / WhatIf-Ausgabe)

.PARAMETER WsusServer
    WSUS-Servername (Standard: SV-OS-WSUS-01)
#>

param(
    [switch]$Force,
    [string]$WsusServer = 'SV-OS-WSUS-01',
    [int]   $WsusPort   = 8530,
    [bool]  $UseSSL     = $false
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$DryRun = -not $Force

function Write-Action {
    param([string]$Action, [string]$Detail = '')
    $Prefix = if ($DryRun) { '[SIMULATION]' } else { '[AUSFUEHREN]' }
    Write-Host "$Prefix $Action" -ForegroundColor $(if ($DryRun) { 'Yellow' } else { 'Green' })
    if ($Detail) { Write-Host "             $Detail" -ForegroundColor Gray }
}

if ($DryRun) {
    Write-Host 'SIMULATION-MODUS: Kein einziger Parameter wird veraendert.' -ForegroundColor Yellow
    Write-Host 'Fuer echte Ausfuehrung: -Force verwenden.' -ForegroundColor Yellow
    Write-Host ''
}

# --- WSUS-Verbindung ---
try {
    Import-Module UpdateServices -ErrorAction Stop
}
catch {
    Add-Type -Path "$env:ProgramFiles\Update Services\Api\Microsoft.UpdateServices.Administration.dll"
}

$Wsus = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer(
    $WsusServer, $UseSSL, $WsusPort
)
Write-Host "WSUS verbunden: $($Wsus.Name) v$($Wsus.Version)" -ForegroundColor Cyan

# --- Ziel-Gruppen definieren ---
$ZielGruppen = @(
    @{
        Name        = 'Ditzler-AutoInstall-Wave1'
        Beschreibung = 'Automatisches Patching Anfang Monat (2./3. Woche). W2019/W2022.'
        AutoApprove = $true
        NoPatch     = $false
    }
    @{
        Name        = 'Ditzler-AutoInstall-Wave2'
        Beschreibung = 'Automatisches Patching Ende Monat (4. Woche). W2019/W2022.'
        AutoApprove = $true
        NoPatch     = $false
    }
    @{
        Name        = 'Ditzler-ManualInstall'
        Beschreibung = 'Scan und Approve; Installation nur via Skript (SuperOps). W2016/W2019.'
        AutoApprove = $false
        NoPatch     = $false
    }
    @{
        Name        = 'Ditzler-NoPatch'
        Beschreibung = 'Scan Only. KEINE Genehmigung. W2012R2 + alle DCs.'
        AutoApprove = $false
        NoPatch     = $true
    }
)

# --- Bestehende Gruppen laden ---
$ExistingGroups = $Wsus.GetComputerTargetGroups() | Group-Object Name -AsHashTable

# Schritt 1: Gruppen erstellen
Write-Host "`n--- Schritt 1: Computergruppen ---"

$GruppenMap = @{}

foreach ($ZG in $ZielGruppen) {
    if ($ExistingGroups.ContainsKey($ZG.Name)) {
        $GruppenMap[$ZG.Name] = $ExistingGroups[$ZG.Name][0]
        Write-Host "  Existiert bereits: $($ZG.Name)" -ForegroundColor Gray
    }
    else {
        Write-Action "Erstelle Gruppe: $($ZG.Name)" $ZG.Beschreibung
        if (-not $DryRun) {
            $NewGroup = $Wsus.CreateComputerTargetGroup($ZG.Name)
            $GruppenMap[$ZG.Name] = $NewGroup
        }
    }
}

# Schritt 2: Approval-Regeln
Write-Host "`n--- Schritt 2: Auto-Approval-Regeln ---"

# Klassifikationen fuer Auto-Approve (Critical Security Updates + Security Updates)
$AllKlass = $Wsus.GetUpdateClassifications()

$KlassAutoApprove = $AllKlass | Where-Object {
    $_.Title -in @('Critical Updates', 'Security Updates')
}

Write-Host "  Klassifikationen fuer Auto-Approve: $($KlassAutoApprove.Title -join ', ')"

# Bestehende Regeln laden
$ExistingRules = $Wsus.GetInstallApprovalRules() | Group-Object Name -AsHashTable

# Regeln fuer Wave1 und Wave2
foreach ($ZG in $ZielGruppen | Where-Object { $_.AutoApprove }) {
    $RegelName = "AutoApprove-$($ZG.Name)"

    if ($ExistingRules.ContainsKey($RegelName)) {
        Write-Host "  Regel existiert bereits: $RegelName" -ForegroundColor Gray
        # Sicherstellen dass sie aktiv ist
        $Regel = $ExistingRules[$RegelName][0]
        if (-not $Regel.Enabled) {
            Write-Action "Aktiviere Regel: $RegelName"
            if (-not $DryRun) {
                $Regel.Enabled = $true
                $Regel.Save()
            }
        }
    }
    else {
        Write-Action "Erstelle Auto-Approval-Regel: $RegelName" `
            "Gruppe: $($ZG.Name) | Klassifikationen: Critical + Security"
        if (-not $DryRun) {
            $Regel = $Wsus.CreateInstallApprovalRule($RegelName)
            $Regel.Enabled = $true

            # Gruppen setzen
            if ($GruppenMap.ContainsKey($ZG.Name)) {
                $GrpColl = $Wsus.CreateComputerTargetGroupCollection()
                $GrpColl.Add($GruppenMap[$ZG.Name])
                $Regel.SetComputerTargetGroups($GrpColl)
            }

            # Klassifikationen setzen
            $KlassColl = $Wsus.CreateUpdateClassificationCollection()
            foreach ($K in $KlassAutoApprove) { $KlassColl.Add($K) }
            $Regel.SetUpdateClassifications($KlassColl)

            $Regel.Save()
        }
    }
}

# Sicherstellen: Keine Auto-Approve-Regel fuer ManualInstall und NoPatch
Write-Host "`n--- Schritt 3: Keine Auto-Approve fuer ManualInstall / NoPatch ---"

$ProtectedGroups = @('Ditzler-ManualInstall', 'Ditzler-NoPatch')

foreach ($Regel in $Wsus.GetInstallApprovalRules()) {
    try {
        $RGruppen = $Regel.GetComputerTargetGroups() | Select-Object -ExpandProperty Name
    } catch { $RGruppen = @() }

    $Konflikt = $RGruppen | Where-Object { $ProtectedGroups -contains $_ }
    if ($Konflikt) {
        Write-Action "WARNUNG: Regel '$($Regel.Name)' betrifft $($Konflikt -join ', ')" `
            "Diese Regel sollte deaktiviert oder angepasst werden!"
        # Wir deaktivieren nicht automatisch - nur warnen
    }
}

# Schritt 4: Statusbericht
Write-Host "`n--- Schritt 4: Aktueller Status ---" -ForegroundColor Cyan

$Wsus.GetComputerTargetGroups() | Sort-Object Name | ForEach-Object {
    $Grp = $_
    try {
        $Count = $Wsus.GetComputerTargetGroup($Grp.Id).GetComputerTargets().Count
    } catch { $Count = '?' }
    Write-Host "  $($Grp.Name.PadRight(40)) $Count Mitglieder"
}

if ($DryRun) {
    Write-Host "`nSimulation beendet. Fuer echte Ausfuehrung: -Force" -ForegroundColor Yellow
} else {
    Write-Host "`nWSUS-Konfiguration abgeschlossen." -ForegroundColor Green
}
