#Requires -Version 5.1
<#
.SYNOPSIS
    Installiert ausstehende Windows Updates via WUA COM-API.
    Dieses Skript wird via SuperOps "runScriptOnAsset" auf dem Zielserver
    ausgefuehrt. Es hat KEINEN Rueckkanal zu SuperOps - der Patch-Status
    wird durch den SuperOps-Agenten nach Abschluss aktualisiert.

.PARAMETER RebootBehavior
    NoReboot         - kein Neustart (Standard, fuer manuelle Runde)
    ScheduledReboot  - Neustart nach 2h einplanen (schtasks)
    ImmediateReboot  - sofortiger Neustart nach Installation

.NOTES
    - Kein Netzwerkzugriff noetig ausser WSUS / Windows Update
    - Laueft unter SYSTEM-Kontext (SuperOps-Agent)
    - Gibt Exit-Code 0 bei Erfolg, 1 bei Fehler zurueck
    - Kompatibel mit WS 2012 R2, 2016, 2019, 2022
#>

param(
    [ValidateSet('NoReboot', 'ScheduledReboot', 'ImmediateReboot')]
    [string]$RebootBehavior = 'NoReboot'
)

$ErrorActionPreference = 'Stop'

function Write-Log {
    param([string]$Message)
    $Stamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    Write-Output "[$Stamp] $Message"
}

Write-Log "Update-Installation gestartet. Reboot-Verhalten: $RebootBehavior"

try {
    # WUA Session initialisieren
    $UpdateSession   = New-Object -ComObject Microsoft.Update.Session
    $UpdateSearcher  = $UpdateSession.CreateUpdateSearcher()

    Write-Log 'Suche nach ausstehenden Updates...'

    # Nur wichtige und empfohlene Updates, kein optionales
    $SearchResult = $UpdateSearcher.Search('IsInstalled=0 and Type=Software and IsHidden=0')

    $TotalUpdates = $SearchResult.Updates.Count
    Write-Log "Gefunden: $TotalUpdates Update(s)"

    if ($TotalUpdates -eq 0) {
        Write-Log 'Keine Updates zu installieren. Fertig.'
        exit 0
    }

    # Updates auflisten
    for ($i = 0; $i -lt $TotalUpdates; $i++) {
        $U = $SearchResult.Updates.Item($i)
        Write-Log "  [$($i+1)] $($U.Title)"
    }

    # Download
    Write-Log 'Download wird gestartet...'
    $Downloader          = $UpdateSession.CreateUpdateDownloader()
    $Downloader.Updates  = $SearchResult.Updates
    $DownloadResult      = $Downloader.Download()

    Write-Log "Download abgeschlossen. ResultCode: $($DownloadResult.ResultCode)"
    # ResultCode: 2=Erfolg, 3=SuccessWithErrors, 4=Fehlgeschlagen
    if ($DownloadResult.ResultCode -eq 4) {
        throw 'Download fehlgeschlagen (ResultCode 4).'
    }

    # Installation
    Write-Log 'Installation wird gestartet...'
    $Installer         = $UpdateSession.CreateUpdateInstaller()
    $Installer.Updates = $SearchResult.Updates

    # Neustart waehrend Installation unterbinden
    $Installer.AllowSourcePrompts = $false

    $InstallResult = $Installer.Install()

    Write-Log "Installation abgeschlossen. ResultCode: $($InstallResult.ResultCode) | Neustart erforderlich: $($InstallResult.RebootRequired)"

    # Einzelergebnisse loggen
    for ($i = 0; $i -lt $TotalUpdates; $i++) {
        $U = $SearchResult.Updates.Item($i)
        $R = $InstallResult.GetUpdateResult($i)
        $Status = switch ($R.ResultCode) {
            0 { 'NotStarted' }
            1 { 'InProgress' }
            2 { 'Succeeded' }
            3 { 'SucceededWithErrors' }
            4 { 'Failed' }
            5 { 'Aborted' }
            default { "Unbekannt ($($R.ResultCode))" }
        }
        Write-Log "  [$($i+1)] $($U.Title) -> $Status (RebootRequired: $($R.RebootRequired))"
    }

    if ($InstallResult.ResultCode -eq 4) {
        throw 'Installation fehlgeschlagen (ResultCode 4).'
    }

    # Neustart-Verhalten
    if ($InstallResult.RebootRequired) {
        Write-Log "Neustart erforderlich."
        switch ($RebootBehavior) {
            'ImmediateReboot' {
                Write-Log 'Sofortiger Neustart wird eingeleitet...'
                shutdown.exe /r /t 30 /c "SuperOps Patch-Neustart" /f
            }
            'ScheduledReboot' {
                Write-Log 'Geplanter Neustart in 2 Stunden wird eingerichtet...'
                $RebootTime = (Get-Date).AddHours(2).ToString('HH:mm')
                schtasks.exe /Create /TN "SuperOps_PatchReboot" /TR "shutdown.exe /r /t 0 /f" `
                    /SC ONCE /ST $RebootTime /F /RU SYSTEM | Out-Null
                Write-Log "Neustart geplant um: $RebootTime"
            }
            'NoReboot' {
                Write-Log 'Kein automatischer Neustart (muss manuell durchgefuehrt werden).'
            }
        }
    }
    else {
        Write-Log 'Kein Neustart erforderlich.'
    }

    Write-Log 'Update-Installation erfolgreich abgeschlossen.'
    exit 0
}
catch {
    Write-Log "FEHLER: $($_.Exception.Message)"
    exit 1
}
