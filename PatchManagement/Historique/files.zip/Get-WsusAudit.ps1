#Requires -Version 5.1
<#
.SYNOPSIS
    Audit der aktuellen WSUS-Konfiguration: Server, Gruppen, Zielgruppenregeln,
    Klassifikationen, Auto-Approval-Regeln und Synchronisationsplan.

.NOTES
    - Muss auf dem WSUS-Server (SV-OS-WSUS-01) oder mit Remotezugriff ausgefuehrt werden
    - Requires UpdateServices-Modul (RSAT-UpdateServices oder WSUS-Rolle)
    - Ausgabe als JSON und Konsolentext fuer Weiterverarbeitung
#>

param(
    [string]$WsusServer   = 'SV-OS-WSUS-01',
    [int]   $WsusPort     = 8530,
    [bool]  $UseSSL       = $false,
    [string]$OutputJson   = ".\WSUS_Audit_$(Get-Date -Format 'yyyyMMdd_HHmm').json"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-Section { param([string]$T) Write-Host "`n=== $T ===" -ForegroundColor Cyan }
function Write-Row     { param([string]$K,[string]$V) Write-Host "  $($K.PadRight(35)) $V" }

# --- WSUS-Verbindung ---
Write-Section 'WSUS-Verbindung'
try {
    Import-Module UpdateServices -ErrorAction Stop
}
catch {
    Write-Warning 'Modul UpdateServices nicht gefunden. Versuche direkte Verbindung via .NET...'
    Add-Type -Path "$env:ProgramFiles\Update Services\Api\Microsoft.UpdateServices.Administration.dll" `
        -ErrorAction Stop
}

$Wsus = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer(
    $WsusServer, $UseSSL, $WsusPort
)
Write-Row 'Server:' $Wsus.Name
Write-Row 'Version:' $Wsus.Version
Write-Row 'Port:' $WsusPort
Write-Row 'SSL:' $UseSSL

# --- Konfiguration ---
Write-Section 'WSUS-Basiskonfiguration'
$Config = $Wsus.GetConfiguration()
Write-Row 'SyncFromMU:' $Config.SyncFromMicrosoftUpdate
Write-Row 'Upstream-Server:' $Config.UpstreamWsusServerName
Write-Row 'Upstream-Port:' $Config.UpstreamWsusServerPortNumber
Write-Row 'SSL upstream:' $Config.UpstreamWsusServerUseSsl
Write-Row 'TargetingMode:' $Config.TargetingMode
# Server-side vs Client-side targeting
Write-Row 'Languages:' ($Config.GetEnabledUpdateLanguages() -join ', ')

# --- Synchronisationsplan ---
Write-Section 'Synchronisationsplan'
$Sub = $Wsus.GetSubscription()
Write-Row 'SynchronizeAutomatically:' $Sub.SynchronizeAutomatically
Write-Row 'SynchronizeAutomaticallyTimeOfDay:' $Sub.SynchronizeAutomaticallyTimeOfDay
Write-Row 'NumberOfSynchronizationsPerDay:' $Sub.NumberOfSynchronizationsPerDay
Write-Row 'LastSynchronizationTime:' $Sub.LastSynchronizationTime
Write-Row 'LastSyncResult:' $Sub.LastSynchronizationResult

# --- Klassifikationen ---
Write-Section 'Aktivierte Klassifikationen'
$Klassifikationen = $Sub.GetUpdateClassifications() | Select-Object -ExpandProperty Title
$Klassifikationen | ForEach-Object { Write-Row '' $_ }

# --- Produkte ---
Write-Section 'Aktivierte Produkte'
$Produkte = $Sub.GetUpdateCategories() | Select-Object -ExpandProperty Title
$Produkte | ForEach-Object { Write-Row '' $_ }

# --- Computer-Gruppen ---
Write-Section 'WSUS Computer-Gruppen'
$GruppenData = [System.Collections.Generic.List[hashtable]]::new()

$Wsus.GetComputerTargetGroups() | Sort-Object Name | ForEach-Object {
    $Gruppe = $_
    try {
        $Members = $Wsus.GetComputerTargetGroup($Gruppe.Id).GetComputerTargets() |
            Select-Object -ExpandProperty FullDomainName
    }
    catch { $Members = @() }

    $GruppenData.Add(@{
        Name    = $Gruppe.Name
        Id      = $Gruppe.Id.ToString()
        Members = @($Members)
        Count   = $Members.Count
    })

    Write-Row "$($Gruppe.Name) ($($Members.Count) Members)" ''
    $Members | ForEach-Object { Write-Row '   ->' $_ }
}

# --- Auto-Approval-Regeln ---
Write-Section 'Auto-Approval-Regeln'
$ApprovalData = [System.Collections.Generic.List[hashtable]]::new()

$Wsus.GetInstallApprovalRules() | ForEach-Object {
    $Regel = $_
    try {
        $RGruppen = ($Regel.GetComputerTargetGroups() | Select-Object -ExpandProperty Name) -join ', '
        $RKlass   = ($Regel.GetUpdateClassifications() | Select-Object -ExpandProperty Title) -join ', '
        $RKats    = ($Regel.GetCategories() | Select-Object -ExpandProperty Title) -join ', '
    }
    catch { $RGruppen = '?'; $RKlass = '?'; $RKats = '?' }

    $ApprovalData.Add(@{
        Name            = $Regel.Name
        Enabled         = $Regel.Enabled
        Action          = $Regel.Action.ToString()
        Gruppen         = $RGruppen
        Klassifikationen = $RKlass
        Kategorien      = $RKats
    })

    Write-Row "Regel: $($Regel.Name)" "(Aktiv: $($Regel.Enabled) | Aktion: $($Regel.Action))"
    Write-Row '  Gruppen:' $RGruppen
    Write-Row '  Klassif.:' $RKlass
}

# --- Declined / Approved Counts ---
Write-Section 'Update-Statistiken (kann laenger dauern)'
try {
    $Scope = New-Object Microsoft.UpdateServices.Administration.UpdateScope
    $Scope.ApprovedStates = [Microsoft.UpdateServices.Administration.ApprovedStates]::NotApproved
    $NotApproved = ($Wsus.GetUpdates($Scope)).Count
    Write-Row 'Nicht genehmigt:' $NotApproved

    $Scope2 = New-Object Microsoft.UpdateServices.Administration.UpdateScope
    $Scope2.ApprovedStates = [Microsoft.UpdateServices.Administration.ApprovedStates]::LatestRevisionApproved
    $Approved = ($Wsus.GetUpdates($Scope2)).Count
    Write-Row 'Genehmigt:' $Approved
}
catch {
    Write-Row 'Statistik:' "Fehler: $($_.Exception.Message)"
}

# --- JSON-Export ---
$Result = @{
    Timestamp        = (Get-Date -Format 'o')
    WsusServer       = $WsusServer
    Port             = $WsusPort
    Config           = @{
        SyncFromMU       = $Config.SyncFromMicrosoftUpdate
        TargetingMode    = $Config.TargetingMode.ToString()
        UpstreamServer   = $Config.UpstreamWsusServerName
        Languages        = @($Config.GetEnabledUpdateLanguages())
    }
    Sync             = @{
        Auto             = $Sub.SynchronizeAutomatically
        TimeOfDay        = $Sub.SynchronizeAutomaticallyTimeOfDay.ToString()
        PerDay           = $Sub.NumberOfSynchronizationsPerDay
        LastSync         = $Sub.LastSynchronizationTime.ToString('o')
        LastResult       = $Sub.LastSynchronizationResult.ToString()
    }
    Klassifikationen = @($Klassifikationen)
    Produkte         = @($Produkte)
    Gruppen          = $GruppenData.ToArray()
    ApprovalRegeln   = $ApprovalData.ToArray()
}

$Result | ConvertTo-Json -Depth 10 | Out-File -FilePath $OutputJson -Encoding UTF8
Write-Host "`nJSON-Export: $OutputJson" -ForegroundColor Green
