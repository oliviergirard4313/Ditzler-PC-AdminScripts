#Requires -Version 5.1
<#
.SYNOPSIS
    Installiert WSUS-genehmigte Updates via WUA COM-API.
    Wird via SuperOps "runScriptOnAsset" auf dem Zielserver ausgefuehrt.

.DESCRIPTION
    Wichtige Unterschiede zu direktem Windows-Update:
    - Nur Updates aus WSUS (UseWUServer=1 via GPO) werden gefunden
    - Nur Updates, die fuer diese WSUS-Computergruppe GENEHMIGT sind
    - Das ist die korrekte Integration mit der WSUS/GPO-Strategie

    NoPatch-Server (W2012R2, DCs) kommen nie in diese Device-Category ->
    dieses Skript wird nie auf ihnen ausgefuehrt.

.PARAMETER RebootBehavior
    NoReboot | ScheduledReboot | ImmediateReboot

.PARAMETER MaxUpdates
    Maximale Anzahl Updates pro Lauf (Sicherheitslimit, Standard 50)

.OUTPUTS
    Exit 0 = Erfolg oder keine Updates vorhanden
    Exit 1 = Fehler
    Exit 2 = Reboot erforderlich (wenn RebootBehavior=NoReboot)
#>

param(
    [ValidateSet('NoReboot', 'ScheduledReboot', 'ImmediateReboot')]
    [string]$RebootBehavior = 'NoReboot',
    [int]$MaxUpdates = 50
)

$ErrorActionPreference = 'Stop'

function Write-Log {
    param([string]$Msg, [string]$L = 'INFO')
    Write-Output "[$(Get-Date -Format 'HH:mm:ss')][$L] $Msg"
}

Write-Log "=== WSUS-Patch-Installation gestartet ==="
Write-Log "Host: $env:COMPUTERNAME | Reboot: $RebootBehavior"

# Pruefen ob WSUS konfiguriert ist (GPO gesetzt)
$UseWUServer = try {
    (Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' `
        -Name UseWUServer -ErrorAction Stop).UseWUServer
} catch { 0 }

if ($UseWUServer -ne 1) {
    Write-Log 'WARNUNG: UseWUServer ist nicht auf 1 gesetzt. WSUS-GPO greifen noch nicht.' WARN
    # Trotzdem weitermachen - WUA nimmt dann Windows Update direkt
}

$WsusUrl = try {
    (Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' `
        -Name WUServer -ErrorAction Stop).WUServer
} catch { 'Nicht konfiguriert' }

Write-Log "WSUS-URL laut Registry: $WsusUrl"

try {
    # WUA-Session
    $Session    = New-Object -ComObject Microsoft.Update.Session
    $Searcher   = $Session.CreateUpdateSearcher()

    Write-Log 'Suche nach genehmigten Updates (via WSUS)...'

    # IsAssigned=1 = vom WSUS genehmigt fuer diese Gruppe
    # IsInstalled=0 = noch nicht installiert
    # IsHidden=0 = nicht versteckt
    $Result = $Searcher.Search('IsInstalled=0 and IsAssigned=1 and IsHidden=0 and Type=Software')

    $Count = $Result.Updates.Count
    Write-Log "Genehmigte Updates gefunden: $Count"

    if ($Count -eq 0) {
        Write-Log 'Keine genehmigten Updates ausstehend. Fertig.' INFO
        exit 0
    }

    if ($Count -gt $MaxUpdates) {
        Write-Log "WARNUNG: $Count Updates gefunden, Limit ist $MaxUpdates. Nur erste $MaxUpdates werden installiert." WARN
    }

    # Updates auflisten
    for ($i = 0; $i -lt [Math]::Min($Count, $MaxUpdates); $i++) {
        $U = $Result.Updates.Item($i)
        $KB = ($U.KBArticleIDs | ForEach-Object { "KB$_" }) -join ', '
        Write-Log "  [$($i+1)] $KB - $($U.Title)"
    }

    # Download
    Write-Log 'Download...'
    $DL = $Session.CreateUpdateDownloader()
    $DL.Updates = $Result.Updates

    # Nur die ersten $MaxUpdates nehmen wenn noetig
    if ($Count -gt $MaxUpdates) {
        $LimitedColl = New-Object -ComObject Microsoft.Update.UpdateColl
        for ($i = 0; $i -lt $MaxUpdates; $i++) { $LimitedColl.Add($Result.Updates.Item($i)) | Out-Null }
        $DL.Updates = $LimitedColl
    }

    $DLResult = $DL.Download()
    Write-Log "Download-Ergebnis: $($DLResult.ResultCode) (0=NotStarted,1=InProgress,2=OK,3=OKwErrors,4=Failed,5=Aborted)"

    if ($DLResult.ResultCode -eq 4) {
        Write-Log 'Download fehlgeschlagen.' ERR
        exit 1
    }

    # Installation
    Write-Log 'Installation...'
    $Installer                = $Session.CreateUpdateInstaller()
    $Installer.Updates        = $DL.Updates
    $Installer.AllowSourcePrompts = $false
    $Installer.ForceQuiet     = $true

    $InstResult = $Installer.Install()

    Write-Log "Installation-Ergebnis: Code=$($InstResult.ResultCode) | RebootRequired=$($InstResult.RebootRequired)"

    # Einzelergebnisse
    $SuccessCount = 0; $FailCount = 0
    for ($i = 0; $i -lt $DL.Updates.Count; $i++) {
        $U  = $DL.Updates.Item($i)
        $R  = $InstResult.GetUpdateResult($i)
        $KB = ($U.KBArticleIDs | ForEach-Object { "KB$_" }) -join ', '
        $St = switch ($R.ResultCode) {
            2 { 'OK' } 3 { 'OK(Warn)' } 4 { 'FAILED' } 5 { 'Aborted' } default { "Code$($R.ResultCode)" }
        }
        if ($R.ResultCode -eq 2 -or $R.ResultCode -eq 3) { $SuccessCount++ } else { $FailCount++ }
        Write-Log "  $KB $St RebootReq=$($R.RebootRequired)"
    }

    Write-Log "Erfolgreich: $SuccessCount | Fehler: $FailCount"

    if ($InstResult.ResultCode -eq 4) {
        Write-Log 'Installation fehlgeschlagen.' ERR
        exit 1
    }

    # Neustart-Verhalten
    if ($InstResult.RebootRequired) {
        Write-Log "Neustart erforderlich."
        switch ($RebootBehavior) {
            'ImmediateReboot' {
                Write-Log 'Neustart in 60 Sekunden...'
                shutdown.exe /r /t 60 /c "SuperOps WSUS-Patch-Neustart" /f
                exit 0
            }
            'ScheduledReboot' {
                $Time = (Get-Date).AddHours(2).ToString('HH:mm')
                schtasks.exe /Create /TN "SuperOps_PatchReboot" /TR "shutdown.exe /r /t 30 /f" `
                    /SC ONCE /ST $Time /F /RU SYSTEM 2>&1 | Out-Null
                Write-Log "Neustart geplant um: $Time"
                exit 0
            }
            'NoReboot' {
                Write-Log 'Neustart manuell erforderlich (NoReboot).'
                # Exit 2 = Erfolg aber Reboot noetig -> Script-Ergebnis in SuperOps erkennbar
                exit 2
            }
        }
    }

    Write-Log '=== Patch-Installation abgeschlossen (kein Neustart erforderlich) ==='
    exit 0
}
catch {
    Write-Log "UNERWARTETER FEHLER: $($_.Exception.Message)" ERR
    Write-Log $_.ScriptStackTrace ERR
    exit 1
}
