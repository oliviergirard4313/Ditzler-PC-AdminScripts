#Requires -Version 5.1
<#
.SYNOPSIS
    Kreuzt AD-Gruppenmitgliedschaften (CPT_SRV_WSUS-*) mit SuperOps-Asset-Daten
    und dem alten Excel-Wartungsplan. Erstellt eine konsolidierte Servertabelle
    als Grundlage fuer die Neustrukturierung.

.DESCRIPTION
    Quellen:
    1. AD - Alle Server-Computer-Objekte + Gruppenmitgliedschaft CPT_SRV_WSUS-*
    2. SuperOps GraphQL API - Assets mit patchStatus, deviceCategory, OS, Status
    3. Kombiniert -> konsolidierte CSV als "Single Source of Truth"

.PARAMETER ApiKey
    SuperOps API-Key (oder Env-Var SUPEROPS_API_KEY)

.PARAMETER ApiEndpoint
    EU: https://euapi.superops.ai/msp

.PARAMETER Domain
    AD-Domain (Standard: ditzlernet.local)

.PARAMETER WsusGroupPrefix
    Prefix der WSUS-AD-Gruppen (Standard: CPT_SRV_WSUS)

.PARAMETER OutputCsv
    Pfad fuer den konsolidierten Bericht
#>

param(
    [string]$ApiKey        = $env:SUPEROPS_API_KEY,
    [string]$ApiEndpoint   = 'https://euapi.superops.ai/msp',
    [string]$Domain        = 'ditzlernet.local',
    [string]$WsusGroupPrefix = 'CPT_SRV_WSUS',
    [string]$OutputCsv     = ".\Server_Konsolidiert_$(Get-Date -Format 'yyyyMMdd_HHmm').csv"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-Section { param([string]$T) Write-Host "`n=== $T ===" -ForegroundColor Cyan }

# --- Hilfsfunktion SuperOps GraphQL ---
function Invoke-SopsQuery {
    param([string]$Query, [hashtable]$Variables = @{})

    if ([string]::IsNullOrEmpty($ApiKey)) {
        throw 'Kein API-Key. -ApiKey oder Env-Var SUPEROPS_API_KEY setzen.'
    }
    $Body = @{ query = $Query; variables = $Variables } | ConvertTo-Json -Depth 10 -Compress
    $Resp = Invoke-RestMethod -Uri $ApiEndpoint -Method Post -TimeoutSec 60 `
        -Headers @{ 'Content-Type' = 'application/json'; 'apiKey' = $ApiKey } `
        -Body $Body
    if ($Resp.errors) { throw ($Resp.errors.message -join '; ') }
    return $Resp.data
}

# =========================================================
# 1. AD-Daten
# =========================================================
Write-Section 'AD - Server-Objekte laden'
Import-Module ActiveDirectory -ErrorAction Stop

$ADComputers = Get-ADComputer -Filter {
    OperatingSystem -like '*Server*'
} -Properties OperatingSystem, OperatingSystemVersion, Description,
              MemberOf, Enabled, LastLogonDate, DistinguishedName |
    Where-Object { $_.Enabled -eq $true }

Write-Host "  $($ADComputers.Count) aktive Server-Objekte gefunden."

# WSUS-Gruppen laden
Write-Section 'AD - WSUS-Gruppen'

$WsusGroups = Get-ADGroup -Filter { Name -like 'CPT_SRV_WSUS*' } -Properties Members |
    Sort-Object Name

$WsusGroups | ForEach-Object {
    Write-Host "  $($_.Name): $($_.Members.Count) Mitglieder"
}

# Pro Computer: Mitgliedschaft in WSUS-Gruppen ermitteln
$ComputerWsusMap = @{}
foreach ($Grp in $WsusGroups) {
    $Members = Get-ADGroupMember -Identity $Grp -ErrorAction SilentlyContinue |
        Where-Object { $_.objectClass -eq 'computer' }
    foreach ($M in $Members) {
        if (-not $ComputerWsusMap.ContainsKey($M.Name.ToUpper())) {
            $ComputerWsusMap[$M.Name.ToUpper()] = [System.Collections.Generic.List[string]]::new()
        }
        $ComputerWsusMap[$M.Name.ToUpper()].Add($Grp.Name)
    }
}

Write-Host "  $($ComputerWsusMap.Count) Server mit WSUS-Gruppenmitgliedschaft."

# =========================================================
# 2. SuperOps-Daten (paginiert)
# =========================================================
Write-Section 'SuperOps - Asset-Liste laden'

$SopsQuery = @'
query getAssetList($input: ListInfoInput!) {
  getAssetList(input: $input) {
    assets {
      assetId
      name
      hostName
      platform
      platformVersion
      status
      patchStatus
      lastCommunicatedTime
      deviceCategory
    }
    listInfo { totalCount page pageSize }
  }
}
'@

$SopsAssets = [System.Collections.Generic.List[object]]::new()
$Page = 1; $PageSize = 100

do {
    $Data  = Invoke-SopsQuery -Query $SopsQuery -Variables @{ input = @{ page = $Page; pageSize = $PageSize } }
    $Total = $Data.getAssetList.listInfo.totalCount
    $Data.getAssetList.assets | ForEach-Object { $SopsAssets.Add($_) }
    Write-Host "  Seite $Page geladen ($($SopsAssets.Count)/$Total)"
    $Page++
} while (($Page - 1) * $PageSize -lt $Total)

Write-Host "  $($SopsAssets.Count) Assets aus SuperOps geladen."

# SuperOps-Assets als Hashtable fuer schnellen Lookup (nach Hostname)
$SopsMap = @{}
foreach ($A in $SopsAssets) {
    $Key = ($A.hostName ?? $A.name).ToUpper().Split('.')[0]  # ohne Domain
    $SopsMap[$Key] = $A
}

# =========================================================
# 3. Konsolidierung
# =========================================================
Write-Section 'Konsolidierung'

# Fixliste: Server die NIEMALS gepatcht werden sollen
# W2012R2 komplett + alle DCs
$NoPatchList = @(
    # Domain Controllers
    'SV-OS-DC-01', 'SV-OS-DC-02',
    # W2012R2 Server (aus Excel-Analyse)
    'SV-APP-03', 'SV-APP-04',
    'SV-BI-APP-01', 'SV-BI-DB-01',
    'SV-CEE-APP-01', 'SV-CEE-BI-01', 'SV-CEE-DB-01', 'SV-CEE-SOM-01',
    'SV-CEE-TST-01', 'SV-CEE-TST-02',
    'SV-FILE-02',
    'SV-GDSN-APP-01', 'SV-GDSN-APP-02', 'SV-GDSN-DB-01',
    'SV-NLQA-APP-01', 'SV-NLQA-DB-01',
    'SV-OS-BITST-01', 'SV-OS-BITST-02',
    'SV-PRINT-06'
) | ForEach-Object { $_.ToUpper() }

$ConsolidatedRows = [System.Collections.Generic.List[PSCustomObject]]::new()

foreach ($PC in $ADComputers | Sort-Object Name) {
    $PCName = $PC.Name.ToUpper()

    # AD-Infos
    $WsusGrps = if ($ComputerWsusMap.ContainsKey($PCName)) {
        $ComputerWsusMap[$PCName] -join ' | '
    } else { '' }

    # SuperOps-Infos
    $Sops = $SopsMap[$PCName]
    $SopsId     = if ($Sops) { $Sops.assetId } else { 'NICHT IN SOPS' }
    $SopsStatus = if ($Sops) { $Sops.status } else { 'N/A' }
    $SopsPatch  = if ($Sops) { $Sops.patchStatus } else { 'N/A' }
    $SopsCat    = if ($Sops -and $Sops.deviceCategory) { $Sops.deviceCategory.name } else { 'N/A' }
    $SopsOS     = if ($Sops) { $Sops.platform } else { $PC.OperatingSystem }
    $SopsLastOK = if ($Sops) { $Sops.lastCommunicatedTime } else { 'N/A' }

    # OS-Version vereinfachen
    $OSSimple = switch -Wildcard ($SopsOS) {
        '*2012*'  { 'WS2012R2' }
        '*2016*'  { 'WS2016' }
        '*2019*'  { 'WS2019' }
        '*2022*'  { 'WS2022' }
        default   { $SopsOS ?? $PC.OperatingSystem }
    }

    # Ziel-WSUS-Gruppe bestimmen
    $IsDC       = $PC.DistinguishedName -like '*Domain Controllers*'
    $IsNoPatch  = $NoPatchList -contains $PCName -or $IsDC
    $Is2012     = $OSSimple -eq 'WS2012R2'

    $ZielGruppe = if ($IsNoPatch) {
        'KEIN PATCH'
    } elseif ($WsusGrps -match 'AutoInstall-Wave1') {
        'AutoInstall-Wave1'
    } elseif ($WsusGrps -match 'AutoInstall-Wave2') {
        'AutoInstall-Wave2'
    } elseif ($WsusGrps -match 'ManualInstall') {
        'ManualInstall'
    } else {
        'ZUWEISUNG FEHLT'
    }

    # Abweichungen markieren
    $Abweichung = ''
    if ($IsNoPatch -and $WsusGrps -notmatch 'KEIN|NONE' -and $WsusGrps -ne '') {
        $Abweichung += 'WARNUNG: In WSUS-Gruppe aber NoPatch-Server; '
    }
    if ($ZielGruppe -eq 'ZUWEISUNG FEHLT') {
        $Abweichung += 'Kein WSUS-Gruppe zugewiesen; '
    }
    if (-not $Sops) {
        $Abweichung += 'Nicht in SuperOps; '
    }

    $ConsolidatedRows.Add([PSCustomObject]@{
        Name            = $PC.Name
        OSEinfach       = $OSSimple
        ADEnabled       = $PC.Enabled
        IsDC            = $IsDC
        IsNoPatch       = $IsNoPatch
        ADWsusGruppen   = $WsusGrps
        ZielWsusGruppe  = $ZielGruppe
        SopsAssetId     = $SopsId
        SopsOnline      = $SopsStatus
        SopsPatchStatus = $SopsPatch
        SopsCategory    = $SopsCat
        SopsOS          = $SopsOS
        SopsLastContact = $SopsLastOK
        ADDescription   = $PC.Description
        ADLastLogon     = $PC.LastLogonDate
        Abweichung      = $Abweichung.TrimEnd('; ')
    })
}

# =========================================================
# 4. Ausgabe
# =========================================================
Write-Section 'Konsolidierte Tabelle'
$ConsolidatedRows | Format-Table Name, OSEinfach, IsNoPatch, ZielWsusGruppe,
    SopsOnline, SopsPatchStatus, Abweichung -AutoSize

Write-Section 'Korrekturbedarf'
$ToDo = $ConsolidatedRows | Where-Object { $_.Abweichung -ne '' }
if ($ToDo.Count -gt 0) {
    Write-Host "  $($ToDo.Count) Server mit Handlungsbedarf:" -ForegroundColor Yellow
    $ToDo | ForEach-Object {
        Write-Host "  !! $($_.Name): $($_.Abweichung)" -ForegroundColor Yellow
    }
} else {
    Write-Host '  Kein Korrekturbedarf gefunden.' -ForegroundColor Green
}

Write-Section 'Statistik'
Write-Host "  Gesamt Server:          $($ConsolidatedRows.Count)"
Write-Host "  Kein Patch:             $(($ConsolidatedRows | Where-Object { $_.IsNoPatch }).Count)"
Write-Host "  AutoInstall-Wave1:      $(($ConsolidatedRows | Where-Object { $_.ZielWsusGruppe -eq 'AutoInstall-Wave1' }).Count)"
Write-Host "  AutoInstall-Wave2:      $(($ConsolidatedRows | Where-Object { $_.ZielWsusGruppe -eq 'AutoInstall-Wave2' }).Count)"
Write-Host "  ManualInstall:          $(($ConsolidatedRows | Where-Object { $_.ZielWsusGruppe -eq 'ManualInstall' }).Count)"
Write-Host "  Zuweisung fehlt:        $(($ConsolidatedRows | Where-Object { $_.ZielWsusGruppe -eq 'ZUWEISUNG FEHLT' }).Count)"
Write-Host "  Nicht in SuperOps:      $(($ConsolidatedRows | Where-Object { $_.SopsAssetId -eq 'NICHT IN SOPS' }).Count)"

$ConsolidatedRows | Export-Csv -Path $OutputCsv -Delimiter ';' -Encoding UTF8 -NoTypeInformation
Write-Host "`nCSV gespeichert: $OutputCsv" -ForegroundColor Green
