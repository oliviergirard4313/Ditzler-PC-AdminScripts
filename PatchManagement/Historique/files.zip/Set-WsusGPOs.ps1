#Requires -Version 5.1
<#
.SYNOPSIS
    Erstellt / prueft die GPOs fuer die WSUS-Patch-Strategie von Louis Ditzler AG.

.DESCRIPTION
    GPO-Struktur (alle auf ditzlernet.local):

    1. GPO_WSUS_BasisConfig
       - Link: gesamte Domain (alle Computer)
       - Setzt: WSUS-Server-URL, WUStatusServer, UseWUServer=1
       - Setzt NICHT: AUOptions (wird in den Folge-GPOs gesetzt)
       - Targeting: Server-side (WSUS-Gruppen) via Computerkonto

    2. GPO_WSUS_NoPatch
       - Link: OU der Server ODER Security-Filterung auf Gruppe CPT_SRV_WSUS-Servers_NoPatch
       - Setzt: NoAutoUpdate=1, AUOptions=2 (nur benachrichtigen), DisableWindowsUpdateAccess=0
       - WU-Dienst bleibt aktiv (fuer WSUS-Scan/Reporting), aber kein automatisches Download/Install

    3. GPO_WSUS_AutoInstall_Wave1
       - Security-Filter: CPT_SRV_WSUS-Servers_AutoInstall-Wave1
       - Setzt: AUOptions=4 (auto download + scheduled install)
               ScheduledInstallDay=0 (jeden Tag - WSUS-Gruppe steuert den Zeitpunkt)
               ScheduledInstallTime=23
               NoAutoRebootWithLoggedOnUsers=0

    4. GPO_WSUS_AutoInstall_Wave2
       - Security-Filter: CPT_SRV_WSUS-Servers_AutoInstall-Wave2
       - Gleich wie Wave1

    5. GPO_WSUS_ManualInstall
       - Security-Filter: CPT_SRV_WSUS-Servers_ManualInstall
       - Setzt: AUOptions=3 (auto download, notify install)
               NoAutoUpdate=0, NoAutoRebootWithLoggedOnUsers=1

    ACHTUNG zu AUOptions vs WSUS-Approval:
    - AUOptions=4 bedeutet "installiere genehmigte Updates automatisch zur geplanten Zeit"
    - Fuer NoPatch setzen wir AUOptions=2: der Client laedt herunter, aber installiert nicht
      UND wir genehmigen in WSUS keine Updates fuer diese Gruppe -> nichts passiert
    - Noch sicherer: DisableWindowsUpdateAccess=0 lassen, aber UseWUServer=1 und
      in WSUS einfach nie genehmigen (Gruppe Ditzler-NoPatch hat keine Approval-Regel)

.PARAMETER Force
    GPOs tatsaechlich erstellen/aendern (ohne: nur Pruefung + Bericht)

.PARAMETER WsusUrl
    WSUS-URL (Standard: http://SV-OS-WSUS-01:8530)
#>

param(
    [switch]$Force,
    [string]$WsusUrl   = 'http://SV-OS-WSUS-01:8530',
    [string]$Domain    = 'ditzlernet.local',
    [string]$DomainDN  = 'DC=ditzlernet,DC=local'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$DryRun = -not $Force

function Write-Action {
    param([string]$Msg, [string]$Sub = '')
    $Pre = if ($DryRun) { '[SIM]' } else { '[RUN]' }
    Write-Host "$Pre $Msg" -ForegroundColor $(if ($DryRun) { 'Yellow' } else { 'Green' })
    if ($Sub) { Write-Host "       $Sub" -ForegroundColor Gray }
}

function Set-GPRegValue {
    # Setzt einen Registry-Wert in einer GPO (Computer Configuration)
    param(
        [string]$GpoName,
        [string]$Key,
        [string]$ValueName,
        $Value,
        [string]$Type = 'DWord'
    )
    if ($DryRun) {
        Write-Action "  GPO '$GpoName': $Key\$ValueName = $Value ($Type)"
        return
    }
    Set-GPRegistryValue -Name $GpoName -Domain $Domain `
        -Key $Key -ValueName $ValueName -Value $Value -Type $Type | Out-Null
}

if ($DryRun) {
    Write-Host '=== SIMULATION-MODUS === (-Force fuer echte Ausfuehrung)' -ForegroundColor Yellow
}

try { Import-Module GroupPolicy -ErrorAction Stop }
catch { throw 'GroupPolicy-Modul fehlt. Auf DC oder mit RSAT (GPMC) ausfuehren.' }

$WURegKey  = 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
$AURegKey  = 'HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'

# =========================================================
# GPO-Definitionen
# =========================================================
$GPODefs = @(
    @{
        Name        = 'GPO_WSUS_BasisConfig'
        Beschreibung = 'WSUS-Basiseinstellungen fuer alle Server (URL + UseWUServer)'
        Settings    = @(
            @{ Key=$WURegKey;  Name='WUServer';       Value=$WsusUrl;         Type='String' }
            @{ Key=$WURegKey;  Name='WUStatusServer'; Value=$WsusUrl;         Type='String' }
            @{ Key=$AURegKey;  Name='UseWUServer';    Value=1;                Type='DWord'  }
            # Client-Side Targeting aktivieren - Gruppe wird per AD-Gruppe / WSUS server-side gesetzt
            @{ Key=$WURegKey;  Name='TargetGroupEnabled'; Value=0;            Type='DWord'  }
        )
        # Link auf Domain (alle Computer)
        LinkTarget  = $DomainDN
        LinkOrder   = 99  # niedrige Prioritaet - wird von Folge-GPOs ueberschrieben
    }
    @{
        Name        = 'GPO_WSUS_NoPatch'
        Beschreibung = 'Kein automatisches Patching. Nur WSUS-Scan fuer Reporting. W2012R2 + DCs.'
        Settings    = @(
            # WSUS aktiv (fuer Scan/Reporting)
            @{ Key=$AURegKey;  Name='UseWUServer';         Value=1; Type='DWord' }
            # Herunterladen und BENACHRICHTIGEN, aber NIEMALS automatisch installieren
            # Zusaetzlich: WSUS genehmigt fuer diese Gruppe sowieso nichts -> doppelte Absicherung
            @{ Key=$AURegKey;  Name='AUOptions';           Value=2; Type='DWord' }
            @{ Key=$AURegKey;  Name='NoAutoUpdate';        Value=0; Type='DWord' }
            # Kein automatischer Neustart
            @{ Key=$AURegKey;  Name='NoAutoRebootWithLoggedOnUsers'; Value=1; Type='DWord' }
            # WU-Zugang NICHT deaktivieren (sonst kein Scan moeglich)
            @{ Key=$WURegKey;  Name='DisableWindowsUpdateAccess'; Value=0; Type='DWord' }
        )
        SecurityFilter = 'CPT_SRV_WSUS-Servers_NoPatch'
        # Kein direkter Link - nur Security-Filter auf einer Server-OU oder Domain
        LinkTarget   = $DomainDN
    }
    @{
        Name        = 'GPO_WSUS_AutoInstall_Wave1'
        Beschreibung = 'Automatisches Patching Wave1 - Anfang Monat. W2019/W2022.'
        Settings    = @(
            @{ Key=$AURegKey;  Name='AUOptions';              Value=4; Type='DWord' }
            @{ Key=$AURegKey;  Name='NoAutoUpdate';           Value=0; Type='DWord' }
            # Jeden Tag pruefen - Installationszeitpunkt via WSUS-Deadline gesteuert
            @{ Key=$AURegKey;  Name='ScheduledInstallDay';    Value=0; Type='DWord' }
            @{ Key=$AURegKey;  Name='ScheduledInstallTime';   Value=23; Type='DWord' }
            @{ Key=$AURegKey;  Name='NoAutoRebootWithLoggedOnUsers'; Value=0; Type='DWord' }
            # Kein Neustart wenn Benutzer eingeloggt - Server-Umgebung
            @{ Key=$AURegKey;  Name='AutoInstallMinorUpdates'; Value=0; Type='DWord' }
        )
        SecurityFilter = 'CPT_SRV_WSUS-Servers_AutoInstall-Wave1'
        LinkTarget   = $DomainDN
    }
    @{
        Name        = 'GPO_WSUS_AutoInstall_Wave2'
        Beschreibung = 'Automatisches Patching Wave2 - Ende Monat. W2019/W2022.'
        Settings    = @(
            @{ Key=$AURegKey;  Name='AUOptions';              Value=4; Type='DWord' }
            @{ Key=$AURegKey;  Name='NoAutoUpdate';           Value=0; Type='DWord' }
            @{ Key=$AURegKey;  Name='ScheduledInstallDay';    Value=0; Type='DWord' }
            @{ Key=$AURegKey;  Name='ScheduledInstallTime';   Value=23; Type='DWord' }
            @{ Key=$AURegKey;  Name='NoAutoRebootWithLoggedOnUsers'; Value=0; Type='DWord' }
            @{ Key=$AURegKey;  Name='AutoInstallMinorUpdates'; Value=0; Type='DWord' }
        )
        SecurityFilter = 'CPT_SRV_WSUS-Servers_AutoInstall-Wave2'
        LinkTarget   = $DomainDN
    }
    @{
        Name        = 'GPO_WSUS_ManualInstall'
        Beschreibung = 'WSUS-Scan + Auto-Download; Installation nur via SuperOps-Skript.'
        Settings    = @(
            # Auto-Download aber nicht installieren (AUOptions=3)
            @{ Key=$AURegKey;  Name='AUOptions';              Value=3; Type='DWord' }
            @{ Key=$AURegKey;  Name='NoAutoUpdate';           Value=0; Type='DWord' }
            @{ Key=$AURegKey;  Name='NoAutoRebootWithLoggedOnUsers'; Value=1; Type='DWord' }
        )
        SecurityFilter = 'CPT_SRV_WSUS-Servers_ManualInstall'
        LinkTarget   = $DomainDN
    }
)

# =========================================================
# GPOs erstellen / pruefen
# =========================================================
Write-Host "`n--- GPOs ---" -ForegroundColor Cyan

foreach ($GPODef in $GPODefs) {
    Write-Host "`n  $($GPODef.Name)" -ForegroundColor White

    # Existenz pruefen
    $ExistingGPO = Get-GPO -Name $GPODef.Name -Domain $Domain -ErrorAction SilentlyContinue

    if (-not $ExistingGPO) {
        Write-Action "GPO erstellen: $($GPODef.Name)" $GPODef.Beschreibung
        if (-not $DryRun) {
            $ExistingGPO = New-GPO -Name $GPODef.Name -Domain $Domain `
                -Comment $GPODef.Beschreibung
        }
    }
    else {
        Write-Host "    Existiert: $($GPODef.Name)" -ForegroundColor Gray
    }

    # Registry-Einstellungen setzen
    foreach ($S in $GPODef.Settings) {
        Set-GPRegValue -GpoName $GPODef.Name -Key $S.Key `
            -ValueName $S.Name -Value $S.Value -Type $S.Type
    }

    # Security-Filter setzen (falls angegeben)
    if ($GPODef.SecurityFilter) {
        Write-Action "  Security-Filter: $($GPODef.SecurityFilter)" `
            "(Authenticated Users entfernen + Gruppe hinzufuegen)"
        if (-not $DryRun -and $ExistingGPO) {
            # Authenticated Users entfernen
            Set-GPPermission -Name $GPODef.Name -Domain $Domain `
                -PermissionLevel None `
                -TargetName 'Authenticated Users' -TargetType Group | Out-Null

            # Zielgruppe hinzufuegen (Apply Group Policy + Read)
            Set-GPPermission -Name $GPODef.Name -Domain $Domain `
                -PermissionLevel GpoApply `
                -TargetName $GPODef.SecurityFilter -TargetType Group | Out-Null

            # Domain Computers brauchen noch Read (ohne Apply)
            Set-GPPermission -Name $GPODef.Name -Domain $Domain `
                -PermissionLevel GpoRead `
                -TargetName 'Domain Computers' -TargetType Group | Out-Null
        }
    }

    # GPO-Link setzen
    if ($GPODef.LinkTarget -and -not $DryRun -and $ExistingGPO) {
        try {
            Get-GPInheritance -Target $GPODef.LinkTarget -Domain $Domain |
                Select-Object -ExpandProperty GpoLinks |
                Where-Object { $_.DisplayName -eq $GPODef.Name } |
                Out-Null

            # Pruefen ob Link schon existiert
            $ExistingLink = Get-GPInheritance -Target $GPODef.LinkTarget -Domain $Domain |
                Select-Object -ExpandProperty GpoLinks |
                Where-Object { $_.DisplayName -eq $GPODef.Name }

            if (-not $ExistingLink) {
                Write-Action "  GPO-Link: $($GPODef.Name) -> $($GPODef.LinkTarget)"
                New-GPLink -Name $GPODef.Name -Domain $Domain `
                    -Target $GPODef.LinkTarget -LinkEnabled Yes | Out-Null
            } else {
                Write-Host "    Link existiert bereits." -ForegroundColor Gray
            }
        }
        catch {
            Write-Warning "  Link-Fehler: $($_.Exception.Message)"
        }
    }
    elseif ($GPODef.LinkTarget) {
        Write-Action "  GPO-Link wuerde gesetzt: $($GPODef.Name) -> $($GPODef.LinkTarget)"
    }
}

# =========================================================
# GPO-Pruefbericht
# =========================================================
Write-Host "`n--- Aktuelle GPO-Konfiguration (Pruefung) ---" -ForegroundColor Cyan

foreach ($GPODef in $GPODefs) {
    $GPO = Get-GPO -Name $GPODef.Name -Domain $Domain -ErrorAction SilentlyContinue
    if (-not $GPO) {
        Write-Host "  FEHLT: $($GPODef.Name)" -ForegroundColor Red
        continue
    }

    $Links = Get-GPInheritance -Target $DomainDN -Domain $Domain |
        Select-Object -ExpandProperty GpoLinks |
        Where-Object { $_.DisplayName -eq $GPODef.Name }

    Write-Host "  $($GPODef.Name.PadRight(40)) Status=$($GPO.GpoStatus) Links=$($Links.Count)"
}

if ($DryRun) {
    Write-Host "`nSimulation beendet. -Force fuer echte Ausfuehrung." -ForegroundColor Yellow
}
