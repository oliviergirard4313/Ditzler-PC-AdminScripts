#Requires -Version 5.1
<#
.SYNOPSIS
    Halbautomatisches Patching ueber SuperOps API (GraphQL).
    Startet Patch-Installation auf allen Assets einer Device-Category,
    ueberwacht den Fortschritt und erstellt einen Abschlussbericht.

.DESCRIPTION
    Ablauf:
    1. Asset-Liste der gewaehlten Device-Category aus SuperOps abrufen
    2. Auf jedem Asset ein Patch-Skript ausfuehren (via runScriptOnAsset)
    3. Patch-Status zyklisch abfragen bis alle Assets fertig oder Timeout
    4. Bericht als CSV und Konsolenausgabe

    Voraussetzungen SuperOps:
    - API-Key mit RMM-Berechtigung (Settings > API Management)
    - Device Categories angelegt: SV_SW-Std_ Manual-Update-G1 / G2 / G3 / G4
    - Auf jedem Server: SuperOps-Agent aktiv
    - Powershell-Skript "Patch-Install-WUA" in der SuperOps Script Library

    Voraussetzungen Netz:
    - Maschine, die dieses Skript ausfuehrt, muss api.superops.ai oder
      euapi.superops.ai erreichen koennen (HTTPS 443)

.PARAMETER Category
    Name der Device-Category in SuperOps (z.B. "SV_SW-Std_ Manual-Update-G1")

.PARAMETER ApiKey
    SuperOps API-Key. Alternativ als Umgebungsvariable SUPEROPS_API_KEY setzen.

.PARAMETER ApiEndpoint
    GraphQL-Endpunkt. US: https://api.superops.ai/msp
                       EU: https://euapi.superops.ai/msp

.PARAMETER PatchScriptId
    ID des Skripts "Patch-Install-WUA" in der SuperOps Script Library.
    Zuerst mit -ListScripts ermitteln.

.PARAMETER PollingIntervalSec
    Abfrageintervall fuer den Patch-Status in Sekunden (Standard: 120)

.PARAMETER TimeoutMin
    Gesamttimeout fuer die Patch-Runde in Minuten (Standard: 180)

.PARAMETER RebootBehavior
    Neustart-Verhalten: NoReboot | ScheduledReboot | ImmediateReboot
    Wird als Argument an das SuperOps Patch-Skript uebergeben.

.PARAMETER ListScripts
    Nur Skript-Liste ausgeben und beenden (zur ID-Ermittlung)

.PARAMETER ListCategories
    Nur Device-Category-Liste ausgeben und beenden

.PARAMETER ReportPath
    Pfad fuer den CSV-Abschlussbericht (Standard: .\PatchReport_<Datum>.csv)

.EXAMPLE
    # Zuerst Skript-IDs und Kategorien ermitteln:
    .\Invoke-SuperOpsPatchRun.ps1 -ListScripts -ApiKey "xxx"
    .\Invoke-SuperOpsPatchRun.ps1 -ListCategories -ApiKey "xxx"

    # Patch-Lauf fuer Gruppe 1 (W2012R2, 18:00 Uhr starten):
    .\Invoke-SuperOpsPatchRun.ps1 `
        -Category "SV_SW-Std_ Manual-Update-G1" `
        -PatchScriptId "1234567890" `
        -RebootBehavior NoReboot `
        -ApiKey "xxx"
#>

[CmdletBinding(DefaultParameterSetName = 'Run')]
param(
    [Parameter(ParameterSetName = 'Run', Mandatory)]
    [string]$Category,

    [string]$ApiKey = $env:SUPEROPS_API_KEY,

    [string]$ApiEndpoint = 'https://euapi.superops.ai/msp',

    [Parameter(ParameterSetName = 'Run', Mandatory)]
    [string]$PatchScriptId,

    [Parameter(ParameterSetName = 'Run')]
    [int]$PollingIntervalSec = 120,

    [Parameter(ParameterSetName = 'Run')]
    [int]$TimeoutMin = 180,

    [Parameter(ParameterSetName = 'Run')]
    [ValidateSet('NoReboot', 'ScheduledReboot', 'ImmediateReboot')]
    [string]$RebootBehavior = 'NoReboot',

    [Parameter(ParameterSetName = 'ListScripts')]
    [switch]$ListScripts,

    [Parameter(ParameterSetName = 'ListCategories')]
    [switch]$ListCategories,

    [Parameter(ParameterSetName = 'Run')]
    [string]$ReportPath = ".\PatchReport_$(Get-Date -Format 'yyyyMMdd_HHmm').csv"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# --- Hilfsfunktionen ---

function Invoke-SopsGraphQL {
    # Schickt eine GraphQL-Anfrage an die SuperOps API.
    param(
        [string]$Query,
        [hashtable]$Variables = @{}
    )

    if ([string]::IsNullOrEmpty($ApiKey)) {
        throw 'Kein API-Key angegeben. Parameter -ApiKey oder Umgebungsvariable SUPEROPS_API_KEY setzen.'
    }

    $Body = @{
        query     = $Query
        variables = $Variables
    } | ConvertTo-Json -Depth 10 -Compress

    $Headers = @{
        'Content-Type' = 'application/json'
        'apiKey'       = $ApiKey
    }

    try {
        $Response = Invoke-RestMethod `
            -Uri $ApiEndpoint `
            -Method Post `
            -Headers $Headers `
            -Body $Body `
            -TimeoutSec 60
    }
    catch {
        throw "API-Fehler: $($_.Exception.Message)"
    }

    if ($Response.errors) {
        $ErrMsg = ($Response.errors | ForEach-Object { $_.message }) -join '; '
        throw "GraphQL-Fehler: $ErrMsg"
    }

    return $Response.data
}

function Get-SopsAssetList {
    # Alle Assets der angegebenen Device-Category abrufen (paginiert).
    param([string]$CategoryName)

    $Query = @'
query getAssetList($input: ListInfoInput!) {
  getAssetList(input: $input) {
    assets {
      assetId
      name
      hostName
      status
      patchStatus
      platform
      deviceCategory
    }
    listInfo {
      totalCount
      page
      pageSize
    }
  }
}
'@

    $Page     = 1
    $PageSize = 100
    $AllAssets = [System.Collections.Generic.List[object]]::new()

    do {
        $Vars = @{
            input = @{
                page     = $Page
                pageSize = $PageSize
                # Filter nach Device-Category ueber searchText nicht unterstuetzt;
                # wir filtern client-seitig nach deviceCategory.name
            }
        }

        $Data   = Invoke-SopsGraphQL -Query $Query -Variables $Vars
        $Assets = $Data.getAssetList.assets
        $Total  = $Data.getAssetList.listInfo.totalCount

        foreach ($Asset in $Assets) {
            # deviceCategory ist JSON; pruefen ob Name stimmt
            $CatName = $null
            if ($Asset.deviceCategory -and $Asset.deviceCategory.name) {
                $CatName = $Asset.deviceCategory.name
            }
            if ($CatName -eq $CategoryName) {
                $AllAssets.Add($Asset)
            }
        }

        $Page++
    } while (($Page - 1) * $PageSize -lt $Total)

    return $AllAssets
}

function Get-SopsAssetPatchStatus {
    # Aktuellen Patch-Status eines einzelnen Assets abrufen.
    param([string]$AssetId)

    $Query = @'
query getAsset($input: AssetIdentifierInput!) {
  getAsset(input: $input) {
    assetId
    name
    patchStatus
    status
  }
}
'@
    $Vars = @{ input = @{ assetId = $AssetId } }
    $Data = Invoke-SopsGraphQL -Query $Query -Variables $Vars
    return $Data.getAsset
}

function Start-SopsPatchScript {
    # Patch-Installationsskript auf einem Asset starten.
    param(
        [string]$AssetId,
        [string]$ScriptId,
        [string]$RebootBehaviorArg
    )

    $Mutation = @'
mutation runScriptOnAsset($input: RunScriptInput!) {
  runScriptOnAsset(input: $input) {
    actionConfigId
    script {
      scriptId
      name
    }
  }
}
'@

    $Vars = @{
        input = @{
            assetId         = $AssetId
            scriptId        = $ScriptId
            scriptArguments = @(
                @{ name = 'RebootBehavior'; value = $RebootBehaviorArg }
            )
        }
    }

    $Data = Invoke-SopsGraphQL -Query $Mutation -Variables $Vars
    return $Data.runScriptOnAsset
}

function Get-SopsScriptList {
    # Alle verfuegbaren Skripte auflisten (zur ID-Ermittlung).
    $Query = @'
query getScriptList($input: ListInfoInput!) {
  getScriptList(input: $input) {
    scripts {
      scriptId
      name
      language
      custom
    }
    listInfo { totalCount }
  }
}
'@
    $Vars = @{ input = @{ page = 1; pageSize = 200 } }
    $Data = Invoke-SopsGraphQL -Query $Query -Variables $Vars
    return $Data.getScriptList.scripts
}

function Get-SopsDeviceCategories {
    # Alle Device-Categories auflisten (zur Namens-Ermittlung).
    $Query = @'
query getDeviceCategories($input: DeviceCategoryIdentifierInput) {
  getDeviceCategories(input: $input) {
    deviceCategoryId
    name
    custom
    assetClass
  }
}
'@
    $Data = Invoke-SopsGraphQL -Query $Query -Variables @{}
    return $Data.getDeviceCategories
}

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $Stamp = Get-Date -Format 'HH:mm:ss'
    $Color = switch ($Level) {
        'OK'   { 'Green' }
        'WARN' { 'Yellow' }
        'ERR'  { 'Red' }
        default { 'Cyan' }
    }
    Write-Host "[$Stamp][$Level] $Message" -ForegroundColor $Color
}

# --- Modus: Skript-Liste ---

if ($ListScripts) {
    Write-Log 'Lade Skript-Liste aus SuperOps...'
    $Scripts = Get-SopsScriptList
    $Scripts | Sort-Object name | Format-Table scriptId, name, language, custom -AutoSize
    return
}

# --- Modus: Category-Liste ---

if ($ListCategories) {
    Write-Log 'Lade Device-Categories aus SuperOps...'
    $Cats = Get-SopsDeviceCategories
    $Cats | Sort-Object name | Format-Table deviceCategoryId, name, custom -AutoSize
    return
}

# --- Hauptlauf ---

Write-Log "Patch-Lauf gestartet fuer Kategorie: $Category"
Write-Log "Reboot-Verhalten: $RebootBehavior | Timeout: $TimeoutMin Min"

# Schritt 1: Asset-Liste laden
Write-Log 'Lade Asset-Liste aus SuperOps...'
$Assets = Get-SopsAssetList -CategoryName $Category

if ($Assets.Count -eq 0) {
    Write-Log "Keine Assets in Kategorie '$Category' gefunden. Abbruch." -Level WARN
    return
}

Write-Log "$($Assets.Count) Asset(s) gefunden:" -Level OK
$Assets | ForEach-Object {
    Write-Log "  $($_.name) | Online: $($_.status) | PatchStatus: $($_.patchStatus)"
}

# Schritt 2: Nur ONLINE-Assets patchen; OFFLINE merken
$OnlineAssets  = $Assets | Where-Object { $_.status -eq 'ONLINE' }
$OfflineAssets = $Assets | Where-Object { $_.status -ne 'ONLINE' }

if ($OfflineAssets.Count -gt 0) {
    Write-Log "Folgende Assets sind OFFLINE und werden uebersprungen:" -Level WARN
    $OfflineAssets | ForEach-Object { Write-Log "  $($_.name)" -Level WARN }
}

if ($OnlineAssets.Count -eq 0) {
    Write-Log 'Keine ONLINE-Assets verfuegbar. Abbruch.' -Level ERR
    return
}

# Ergebnistabelle initialisieren
$Results = [System.Collections.Generic.List[PSCustomObject]]::new()

foreach ($Asset in $Assets) {
    $Results.Add([PSCustomObject]@{
        AssetId        = $Asset.assetId
        Name           = $Asset.name
        Platform       = $Asset.platform
        Status         = $Asset.status
        PatchStatusPre = $Asset.patchStatus
        ScriptStarted  = $false
        ActionConfigId = ''
        PatchStatusEnd = 'N/A'
        Resultat       = if ($Asset.status -ne 'ONLINE') { 'OFFLINE' } else { 'Pending' }
        Fehler         = ''
    })
}

# Schritt 3: Skript auf allen ONLINE-Assets starten
Write-Log 'Starte Patch-Skript auf ONLINE-Assets...'

foreach ($Asset in $OnlineAssets) {
    $Row = $Results | Where-Object { $_.AssetId -eq $Asset.assetId }
    try {
        $RunResult = Start-SopsPatchScript `
            -AssetId $Asset.assetId `
            -ScriptId $PatchScriptId `
            -RebootBehaviorArg $RebootBehavior

        $Row.ScriptStarted  = $true
        $Row.ActionConfigId = $RunResult.actionConfigId
        $Row.Resultat       = 'Running'
        Write-Log "  $($Asset.name) -> Skript gestartet (ActionId: $($RunResult.actionConfigId))" -Level OK
    }
    catch {
        $Row.Resultat = 'StartFehler'
        $Row.Fehler   = $_.Exception.Message
        Write-Log "  $($Asset.name) -> Fehler beim Starten: $($_.Exception.Message)" -Level ERR
    }

    # Kurze Pause zwischen Skript-Starts (Rate-Limiting)
    Start-Sleep -Seconds 3
}

# Schritt 4: Polling bis alle fertig oder Timeout
$Deadline = (Get-Date).AddMinutes($TimeoutMin)

Write-Log "Ueberwachung gestartet. Timeout: $(Get-Date $Deadline -Format 'HH:mm:ss') | Intervall: $PollingIntervalSec s"

$PendingAssets = $OnlineAssets | Where-Object {
    ($Results | Where-Object { $_.AssetId -eq $_.AssetId -and $_.Resultat -eq 'Running' }).Count -gt 0
}

# Vereinfacht: alle gestarteten Assets als "zu ueberwachen" betrachten
$MonitorIds = ($Results | Where-Object { $_.ScriptStarted -eq $true }).AssetId

do {
    Start-Sleep -Seconds $PollingIntervalSec

    $StillRunning = 0

    foreach ($AssetId in $MonitorIds) {
        $Row = $Results | Where-Object { $_.AssetId -eq $AssetId }

        # Nur aktive Assets pollen
        if ($Row.Resultat -notin @('Running', 'Pending')) { continue }

        try {
            $AssetInfo = Get-SopsAssetPatchStatus -AssetId $AssetId
            $Row.PatchStatusEnd = $AssetInfo.patchStatus

            switch ($AssetInfo.patchStatus) {
                'Fully Patched' {
                    $Row.Resultat = 'OK'
                    Write-Log "  $($Row.Name) -> Fully Patched" -Level OK
                }
                'Reboot required' {
                    $Row.Resultat = 'RebootRequired'
                    Write-Log "  $($Row.Name) -> Reboot erforderlich" -Level WARN
                }
                'Install pending' {
                    $Row.Resultat = 'Running'
                    $StillRunning++
                    Write-Log "  $($Row.Name) -> Noch nicht abgeschlossen (Install pending)"
                }
                default {
                    # Unbekannt oder kein Wechsel - weiter warten
                    $Row.Resultat = 'Running'
                    $StillRunning++
                    Write-Log "  $($Row.Name) -> Status: $($AssetInfo.patchStatus)"
                }
            }
        }
        catch {
            Write-Log "  $($Row.Name) -> Fehler beim Status-Abruf: $($_.Exception.Message)" -Level WARN
            $StillRunning++
        }
    }

    $Done = $MonitorIds.Count - $StillRunning
    Write-Log "Fortschritt: $Done/$($MonitorIds.Count) abgeschlossen. Noch laufend: $StillRunning"

} while ($StillRunning -gt 0 -and (Get-Date) -lt $Deadline)

# Timeout-Markierung fuer noch laufende Assets
foreach ($AssetId in $MonitorIds) {
    $Row = $Results | Where-Object { $_.AssetId -eq $AssetId }
    if ($Row.Resultat -eq 'Running') {
        $Row.Resultat = 'Timeout'
        Write-Log "  $($Row.Name) -> Timeout - Status unklar!" -Level WARN
    }
}

# Schritt 5: Abschlussbericht
Write-Log ''
Write-Log '========== ABSCHLUSSBERICHT ==========' -Level OK

$Results | Format-Table Name, Platform, PatchStatusPre, PatchStatusEnd, Resultat, Fehler -AutoSize

# CSV-Export
$Results | Export-Csv -Path $ReportPath -Delimiter ';' -Encoding UTF8 -NoTypeInformation
Write-Log "Bericht gespeichert: $ReportPath" -Level OK

# Zusammenfassung
$OK             = ($Results | Where-Object { $_.Resultat -eq 'OK' }).Count
$RebootRequired = ($Results | Where-Object { $_.Resultat -eq 'RebootRequired' }).Count
$Errors         = ($Results | Where-Object { $_.Resultat -in @('StartFehler', 'Timeout') }).Count
$Offline        = ($Results | Where-Object { $_.Resultat -eq 'OFFLINE' }).Count

Write-Log "OK: $OK | RebootRequired: $RebootRequired | Fehler/Timeout: $Errors | Offline: $Offline"
