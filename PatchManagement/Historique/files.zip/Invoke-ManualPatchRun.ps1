#Requires -Version 5.1
<#
.SYNOPSIS
    Halbautomatisches Patching der ManualInstall-Server via SuperOps API.
    Nutzt WSUS-genehmigte Updates (WUA) - kein direkter Windows Update Zugriff.

.DESCRIPTION
    Ablauf:
    0. Voraussetzung: Updates wurden in WSUS fuer Gruppe Ditzler-ManualInstall genehmigt
       (via WSUS-Konsole oder Approval-Skript)
    1. Assets der Device-Category aus SuperOps abrufen
    2. Online-Status pruefen
    3. Pro Asset: SuperOps runScriptOnAsset mit Install-WsusApprovedUpdates.ps1
    4. Polling des Patch-Status via SuperOps API
    5. Abschlussbericht CSV

.PARAMETER Category
    SuperOps Device-Category (z.B. "SV_SW-Std_ Manual-Update-G1")

.PARAMETER ApiKey
    SuperOps API-Key (oder Env-Var SUPEROPS_API_KEY)

.PARAMETER PatchScriptId
    ID des Skripts "Install-WsusApprovedUpdates" in SuperOps Script Library
    (Ermitteln mit -ListScripts)

.PARAMETER RebootBehavior
    NoReboot | ScheduledReboot | ImmediateReboot

.PARAMETER ListScripts / -ListCategories
    Nur Listen ausgeben, kein Patch-Lauf

.PARAMETER ApproveInWsus
    Patches fuer die Gruppe in WSUS genehmigen BEVOR die Installation startet.
    Erfordert -WsusServer und Zugriff auf WSUS-Konsole.

.PARAMETER WsusServer
    WSUS-Servername (nur relevant mit -ApproveInWsus)
#>

[CmdletBinding(DefaultParameterSetName = 'Run')]
param(
    [Parameter(ParameterSetName = 'Run', Mandatory)]
    [string]$Category,

    [string]$ApiKey        = $env:SUPEROPS_API_KEY,
    [string]$ApiEndpoint   = 'https://euapi.superops.ai/msp',

    [Parameter(ParameterSetName = 'Run', Mandatory)]
    [string]$PatchScriptId,

    [Parameter(ParameterSetName = 'Run')]
    [ValidateSet('NoReboot', 'ScheduledReboot', 'ImmediateReboot')]
    [string]$RebootBehavior = 'NoReboot',

    [Parameter(ParameterSetName = 'Run')]
    [switch]$ApproveInWsus,

    [Parameter(ParameterSetName = 'Run')]
    [string]$WsusServer      = 'SV-OS-WSUS-01',

    [Parameter(ParameterSetName = 'Run')]
    [string]$WsusGroupName   = 'Ditzler-ManualInstall',

    [Parameter(ParameterSetName = 'Run')]
    [int]$PollingIntervalSec = 120,

    [Parameter(ParameterSetName = 'Run')]
    [int]$TimeoutMin         = 240,

    [Parameter(ParameterSetName = 'Run')]
    [string]$ReportPath      = ".\PatchReport_$(Get-Date -Format 'yyyyMMdd_HHmm').csv",

    [Parameter(ParameterSetName = 'ListScripts')]
    [switch]$ListScripts,

    [Parameter(ParameterSetName = 'ListCategories')]
    [switch]$ListCategories
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# =========================================================
# API-Hilfsfunktionen
# =========================================================
function Invoke-SopsQuery {
    param([string]$Query, [hashtable]$Variables = @{})
    if ([string]::IsNullOrEmpty($ApiKey)) { throw 'API-Key fehlt.' }
    $Body = @{ query = $Query; variables = $Variables } | ConvertTo-Json -Depth 10 -Compress
    $Resp = Invoke-RestMethod -Uri $ApiEndpoint -Method Post -TimeoutSec 60 `
        -Headers @{ 'Content-Type' = 'application/json'; 'apiKey' = $ApiKey } `
        -Body $Body
    if ($Resp.errors) { throw ($Resp.errors.message -join '; ') }
    return $Resp.data
}

function Get-SopsAssetsByCategory {
    param([string]$CategoryName)
    $Q = @'
query getAssetList($input: ListInfoInput!) {
  getAssetList(input: $input) {
    assets { assetId name hostName platform status patchStatus lastCommunicatedTime deviceCategory }
    listInfo { totalCount page pageSize }
  }
}
'@
    $All = [System.Collections.Generic.List[object]]::new()
    $Page = 1; $PageSize = 100
    do {
        $D = Invoke-SopsQuery -Query $Q -Variables @{ input = @{ page=$Page; pageSize=$PageSize } }
        $T = $D.getAssetList.listInfo.totalCount
        $D.getAssetList.assets | Where-Object {
            $_.deviceCategory -and $_.deviceCategory.name -eq $CategoryName
        } | ForEach-Object { $All.Add($_) }
        $Page++
    } while (($Page-1)*$PageSize -lt $T)
    return $All
}

function Invoke-SopsScript {
    param([string]$AssetId, [string]$ScriptId, [string]$Reboot)
    $M = @'
mutation runScriptOnAsset($input: RunScriptInput!) {
  runScriptOnAsset(input: $input) { actionConfigId script { scriptId name } }
}
'@
    $D = Invoke-SopsQuery -Query $M -Variables @{
        input = @{
            assetId         = $AssetId
            scriptId        = $ScriptId
            scriptArguments = @(@{ name='RebootBehavior'; value=$Reboot })
        }
    }
    return $D.runScriptOnAsset
}

function Get-SopsAsset {
    param([string]$AssetId)
    $Q = @'
query getAsset($input: AssetIdentifierInput!) {
  getAsset(input: $input) { assetId name status patchStatus lastCommunicatedTime }
}
'@
    return (Invoke-SopsQuery -Query $Q -Variables @{ input=@{ assetId=$AssetId } }).getAsset
}

function Get-SopsScripts {
    $Q = @'
query getScriptList($input: ListInfoInput!) {
  getScriptList(input: $input) { scripts { scriptId name language custom } listInfo { totalCount } }
}
'@
    return (Invoke-SopsQuery -Query $Q -Variables @{ input=@{ page=1; pageSize=200 } }).getScriptList.scripts
}

function Get-SopsDevCats {
    $Q = 'query { getDeviceCategories { deviceCategoryId name custom } }'
    return (Invoke-SopsQuery -Query $Q).getDeviceCategories
}

function Write-Log {
    param([string]$Msg, [string]$L = 'INFO')
    $C = switch ($L) { 'OK' { 'Green' } 'WARN' { 'Yellow' } 'ERR' { 'Red' } default { 'Cyan' } }
    Write-Host "[$(Get-Date -Format 'HH:mm:ss')][$L] $Msg" -ForegroundColor $C
}

# =========================================================
# Hilfsmodus
# =========================================================
if ($ListScripts) {
    Write-Log 'SuperOps Skript-Liste:'
    Get-SopsScripts | Sort-Object name | Format-Table scriptId, name, language, custom -AutoSize
    return
}
if ($ListCategories) {
    Write-Log 'SuperOps Device-Categories:'
    Get-SopsDevCats | Sort-Object name | Format-Table deviceCategoryId, name, custom -AutoSize
    return
}

# =========================================================
# Optional: WSUS-Genehmigung vor Installation
# =========================================================
if ($ApproveInWsus) {
    Write-Log "WSUS: Genehmige ausstehende Updates fuer Gruppe '$WsusGroupName'..."
    try {
        try { Import-Module UpdateServices -ErrorAction Stop }
        catch { Add-Type -Path "$env:ProgramFiles\Update Services\Api\Microsoft.UpdateServices.Administration.dll" }

        $Wsus   = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer($WsusServer, $false, 8530)
        $Gruppe = $Wsus.GetComputerTargetGroups() | Where-Object { $_.Name -eq $WsusGroupName }

        if (-not $Gruppe) { throw "WSUS-Gruppe '$WsusGroupName' nicht gefunden." }

        # Ungenehmige Updates suchen
        $Scope = New-Object Microsoft.UpdateServices.Administration.UpdateScope
        $Scope.ApprovedStates = [Microsoft.UpdateServices.Administration.ApprovedStates]::NotApproved

        $Ungenehmigt = $Wsus.GetUpdates($Scope) | Where-Object {
            -not $_.IsDeclined -and
            $_.UpdateClassification.Title -in @('Critical Updates', 'Security Updates', 'Updates')
        }

        Write-Log "$($Ungenehmigt.Count) Updates werden genehmigt..."

        $GrpColl = $Wsus.CreateComputerTargetGroupCollection()
        $GrpColl.Add($Gruppe)

        foreach ($U in $Ungenehmigt) {
            try {
                $U.Approve(
                    [Microsoft.UpdateServices.Administration.UpdateApprovalAction]::Install,
                    $GrpColl
                ) | Out-Null
                Write-Log "  Genehmigt: $($U.Title)" -L OK
            }
            catch {
                Write-Log "  Fehler: $($U.Title) -> $($_.Exception.Message)" -L WARN
            }
        }
    }
    catch {
        Write-Log "WSUS-Fehler: $($_.Exception.Message)" -L ERR
        Write-Log 'WSUS-Genehmigung fehlgeschlagen. Abbruch.' -L ERR
        exit 1
    }
}

# =========================================================
# Hauptlauf
# =========================================================
Write-Log "Patch-Lauf: $Category | Reboot: $RebootBehavior | Timeout: $TimeoutMin Min"

# 1. Assets laden
Write-Log 'Lade Assets aus SuperOps...'
$Assets = Get-SopsAssetsByCategory -CategoryName $Category

if ($Assets.Count -eq 0) {
    Write-Log "Keine Assets in '$Category' gefunden." -L WARN; return
}

Write-Log "$($Assets.Count) Assets gefunden:" -L OK
$Assets | ForEach-Object {
    Write-Log "  $($_.name.PadRight(25)) Online=$($_.status) Patch=$($_.patchStatus)"
}

# 2. Ergebnis-Tabelle initialisieren
$Results = $Assets | ForEach-Object {
    [PSCustomObject]@{
        AssetId        = $_.assetId
        Name           = $_.name
        Platform       = $_.platform
        StatusOnline   = $_.status
        PatchStatusPre = $_.patchStatus
        ScriptStarted  = $false
        ActionConfigId = ''
        PatchStatusEnd = 'N/A'
        Ergebnis       = if ($_.status -ne 'ONLINE') { 'OFFLINE' } else { 'Pending' }
        Fehler         = ''
    }
}

# 3. Skript starten (nur ONLINE-Assets)
Write-Log 'Starte Patch-Skript auf ONLINE-Assets...'

foreach ($Row in ($Results | Where-Object { $_.Ergebnis -eq 'Pending' })) {
    try {
        $Run = Invoke-SopsScript -AssetId $Row.AssetId -ScriptId $PatchScriptId -Reboot $RebootBehavior
        $Row.ScriptStarted  = $true
        $Row.ActionConfigId = $Run.actionConfigId
        $Row.Ergebnis       = 'Running'
        Write-Log "  $($Row.Name) -> Skript gestartet (Action: $($Run.actionConfigId))" -L OK
    }
    catch {
        $Row.Ergebnis = 'StartFehler'
        $Row.Fehler   = $_.Exception.Message
        Write-Log "  $($Row.Name) -> Startfehler: $($_.Exception.Message)" -L ERR
    }
    Start-Sleep -Seconds 2
}

# 4. Polling
$Deadline    = (Get-Date).AddMinutes($TimeoutMin)
$MonitorIds  = ($Results | Where-Object { $_.ScriptStarted }).AssetId

Write-Log "Monitoring bis $(Get-Date $Deadline -Format 'HH:mm:ss') (alle $PollingIntervalSec s)"

do {
    Start-Sleep -Seconds $PollingIntervalSec
    $Running = 0

    foreach ($AssetId in $MonitorIds) {
        $Row = $Results | Where-Object { $_.AssetId -eq $AssetId }
        if ($Row.Ergebnis -notin @('Running')) { continue }

        try {
            $Info = Get-SopsAsset -AssetId $AssetId
            $Row.PatchStatusEnd = $Info.patchStatus

            $Row.Ergebnis = switch ($Info.patchStatus) {
                'Fully Patched'    { Write-Log "  $($Row.Name) -> Fully Patched" -L OK; 'OK' }
                'Reboot required'  { Write-Log "  $($Row.Name) -> Reboot erforderlich" -L WARN; 'RebootRequired' }
                'Install pending'  { $Running++; Write-Log "  $($Row.Name) -> Noch laufend"; 'Running' }
                default            { $Running++; Write-Log "  $($Row.Name) -> $($Info.patchStatus)"; 'Running' }
            }
        }
        catch {
            $Running++
            Write-Log "  $($Row.Name) -> Status-Fehler: $($_.Exception.Message)" -L WARN
        }
    }

    $Done = $MonitorIds.Count - $Running
    Write-Log "Fortschritt: $Done/$($MonitorIds.Count) fertig, $Running laufend"

} while ($Running -gt 0 -and (Get-Date) -lt $Deadline)

# Timeout-Markierung
$Results | Where-Object { $_.Ergebnis -eq 'Running' } | ForEach-Object {
    $_.Ergebnis = 'Timeout'
    Write-Log "  $($_.Name) -> TIMEOUT" -L WARN
}

# 5. Abschlussbericht
Write-Log "`n========== ABSCHLUSSBERICHT ==========" -L OK
$Results | Format-Table Name, Platform, PatchStatusPre, PatchStatusEnd, Ergebnis, Fehler -AutoSize

$Results | Export-Csv -Path $ReportPath -Delimiter ';' -Encoding UTF8 -NoTypeInformation
Write-Log "Bericht: $ReportPath" -L OK

$OK    = ($Results | Where-Object { $_.Ergebnis -eq 'OK' }).Count
$Reb   = ($Results | Where-Object { $_.Ergebnis -eq 'RebootRequired' }).Count
$Err   = ($Results | Where-Object { $_.Ergebnis -in @('StartFehler','Timeout') }).Count
$Off   = ($Results | Where-Object { $_.Ergebnis -eq 'OFFLINE' }).Count
Write-Log "OK=$OK | RebootRequired=$Reb | Fehler/Timeout=$Err | Offline=$Off"
