#Requires -Version 5.1
<#
.SYNOPSIS
    Audit der GPO-Einstellungen fuer Windows Update / WSUS auf allen
    Servern in ditzlernet.local. Liest alle relevanten WU-Registrierungsschluesseln
    direkt von den Computern (kein RSAT-GPO-Modul erforderlich auf Zielen).

    Liefert pro Server:
    - Welche WSUS-URL konfiguriert ist
    - WUStatusServer
    - Targeting-Gruppenname (clientseitiges Targeting)
    - Auto-Update-Verhalten (AUOptions)
    - Geplante Installationszeit
    - Herkunft (GPO / lokal / nicht konfiguriert)
#>

param(
    # Kommaseparierte Serverliste ODER leer = aus AD lesen
    [string[]]$ServerList   = @(),
    [string]  $Domain       = 'ditzlernet.local',
    [string]  $OutputCsv    = ".\GPO_WU_Audit_$(Get-Date -Format 'yyyyMMdd_HHmm').csv",
    [int]     $MaxJobs      = 20,
    [int]     $TimeoutSec   = 30
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'SilentlyContinue'

# --- Serverliste aus AD laden falls nicht angegeben ---
if ($ServerList.Count -eq 0) {
    Write-Host 'Lade Serverliste aus Active Directory...' -ForegroundColor Cyan
    try {
        Import-Module ActiveDirectory -ErrorAction Stop
        $ADServer = Get-ADComputer -Filter {
            OperatingSystem -like '*Server*'
        } -Properties OperatingSystem, DistinguishedName |
            Where-Object { $_.Enabled -eq $true }
        $ServerList = $ADServer.Name
        Write-Host "  $($ServerList.Count) Server aus AD geladen." -ForegroundColor Green
    }
    catch {
        Write-Warning "AD-Abfrage fehlgeschlagen: $($_.Exception.Message)"
        Write-Warning 'Bitte -ServerList manuell angeben.'
        exit 1
    }
}

# --- Registry-Werte remote auslesen (Scriptblock) ---
$RemoteBlock = {
    param($Computer)

    $WUKey     = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
    $AUKey     = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'
    $WUKeyLoc  = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate'

    function Get-RegVal {
        param([string]$Path, [string]$Name)
        try { (Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop).$Name }
        catch { $null }
    }

    # WSUS-Server aus Policy
    $WUServer      = Get-RegVal $WUKey     'WUServer'
    $WUStatusSrv   = Get-RegVal $WUKey     'WUStatusServer'
    $TargetGroup   = Get-RegVal $WUKey     'TargetGroup'
    $TargetEnabled = Get-RegVal $WUKey     'TargetGroupEnabled'
    $DisableWUAcc  = Get-RegVal $WUKey     'DisableWindowsUpdateAccess'

    # Auto-Update-Verhalten
    $NoAutoUpdate  = Get-RegVal $AUKey     'NoAutoUpdate'
    $AUOptions     = Get-RegVal $AUKey     'AUOptions'
    $ScheduledDay  = Get-RegVal $AUKey     'ScheduledInstallDay'
    $ScheduledTime = Get-RegVal $AUKey     'ScheduledInstallTime'
    $NoAutoReboot  = Get-RegVal $AUKey     'NoAutoRebootWithLoggedOnUsers'
    $UseWUServer   = Get-RegVal $AUKey     'UseWUServer'
    $AutoInstall   = Get-RegVal $AUKey     'AutoInstallMinorUpdates'

    # Letztes Update-Datum (lokal, kein Policy-Schluessel)
    $LastSuccess   = Get-RegVal $WUKeyLoc  'LastSuccessTime'

    # AUOptions-Bedeutung
    $AUDesc = switch ($AUOptions) {
        2 { 'Notify before download' }
        3 { 'Auto download, notify install' }
        4 { 'Auto download and schedule install' }
        5 { 'Allow local admin to choose' }
        default { if ($null -eq $AUOptions) { 'Not configured' } else { "Unknown ($AUOptions)" } }
    }

    # OS-Version
    $OS = (Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue).Caption

    [PSCustomObject]@{
        Computer        = $Computer
        OS              = $OS
        WUServer        = $WUServer
        WUStatusServer  = $WUStatusSrv
        UseWUServer     = $UseWUServer
        TargetGroup     = $TargetGroup
        TargetEnabled   = $TargetEnabled
        AUOptions       = $AUOptions
        AUOptionDesc    = $AUDesc
        NoAutoUpdate    = $NoAutoUpdate
        ScheduledDay    = $ScheduledDay
        ScheduledTime   = $ScheduledTime
        NoAutoReboot    = $NoAutoReboot
        DisableWUAccess = $DisableWUAcc
        LastSuccessTime = $LastSuccess
        WSUSConfigured  = ($null -ne $WUServer -and $WUServer -ne '')
    }
}

# --- Parallele Ausfuehrung via Jobs ---
Write-Host "Starte Audit auf $($ServerList.Count) Servern (Max. $MaxJobs parallel)..." -ForegroundColor Cyan

$Results  = [System.Collections.Generic.List[PSCustomObject]]::new()
$Jobs     = @{}
$Pending  = [System.Collections.Queue]::new()
$ServerList | ForEach-Object { $Pending.Enqueue($_) }

while ($Pending.Count -gt 0 -or $Jobs.Count -gt 0) {

    # Neue Jobs starten
    while ($Jobs.Count -lt $MaxJobs -and $Pending.Count -gt 0) {
        $Srv = $Pending.Dequeue()
        $Job = Start-Job -ScriptBlock {
            param($C, $B) Invoke-Command -ComputerName $C -ScriptBlock $B `
                -ArgumentList $C -ErrorAction SilentlyContinue
        } -ArgumentList $Srv, $RemoteBlock
        $Jobs[$Srv] = $Job
    }

    # Fertige Jobs einsammeln
    $Done = $Jobs.GetEnumerator() | Where-Object {
        $_.Value.State -in @('Completed', 'Failed', 'Stopped')
    }

    foreach ($Entry in $Done) {
        $Srv = $Entry.Key
        $Job = $Entry.Value
        try {
            $R = Receive-Job -Job $Job -ErrorAction Stop
            if ($R) {
                $Results.Add($R)
                $Status = if ($R.WSUSConfigured) { 'OK' } else { '!!' }
                Write-Host "  [$Status] $Srv | WSUS=$($R.WUServer) | Group=$($R.TargetGroup) | AU=$($R.AUOptionDesc)"
            }
            else {
                $Results.Add([PSCustomObject]@{
                    Computer = $Srv; OS = 'N/A'; WUServer = 'UNREACHABLE'
                    WSUSConfigured = $false
                })
                Write-Host "  [--] $Srv -> Nicht erreichbar" -ForegroundColor Yellow
            }
        }
        catch {
            Write-Host "  [ERR] $Srv -> $($_.Exception.Message)" -ForegroundColor Red
        }
        Remove-Job -Job $Job -Force
        $Jobs.Remove($Srv)
    }

    if ($Jobs.Count -gt 0) { Start-Sleep -Milliseconds 500 }
}

# --- GPO-Analyse (welche GPOs setzen WU-Einstellungen) ---
Write-Host "`n=== GPO-Analyse ===" -ForegroundColor Cyan

try {
    Import-Module GroupPolicy -ErrorAction Stop

    # Alle GPOs durchsuchen nach WU/WSUS-Einstellungen
    $AllGPOs   = Get-GPO -All -Domain $Domain
    $WUGPOList = [System.Collections.Generic.List[PSCustomObject]]::new()

    foreach ($GPO in $AllGPOs) {
        try {
            $Report = Get-GPOReport -Guid $GPO.Id -ReportType Xml -Domain $Domain
            if ($Report -match 'WindowsUpdate' -or $Report -match 'WUServer' -or $Report -match 'AUOptions') {
                $WUGPOList.Add([PSCustomObject]@{
                    Name    = $GPO.DisplayName
                    Id      = $GPO.Id
                    Status  = $GPO.GpoStatus
                    Changed = $GPO.ModificationTime
                })
                Write-Host "  GPO mit WU-Einstellungen: $($GPO.DisplayName)"
            }
        }
        catch { <# GPO ohne Report-Zugriff ueberspringen #> }
    }

    if ($WUGPOList.Count -eq 0) {
        Write-Host '  Keine GPOs mit WU-Einstellungen gefunden (oder kein Zugriff).' -ForegroundColor Yellow
    }
}
catch {
    Write-Warning "GroupPolicy-Modul nicht verfuegbar: $($_.Exception.Message)"
    Write-Warning 'GPO-Analyse uebersprungen. RSAT-GroupPolicy installieren oder auf DC ausfuehren.'
}

# --- Zusammenfassung ---
Write-Host "`n=== Zusammenfassung ===" -ForegroundColor Cyan
$Configured   = ($Results | Where-Object { $_.WSUSConfigured }).Count
$NotConfig    = ($Results | Where-Object { -not $_.WSUSConfigured }).Count
$Unreachable  = ($Results | Where-Object { $_.WUServer -eq 'UNREACHABLE' }).Count

Write-Host "  Gesamt:          $($Results.Count)"
Write-Host "  WSUS konfiguriert: $Configured"
Write-Host "  Nicht konfiguriert: $NotConfig"
Write-Host "  Nicht erreichbar:  $Unreachable"

Write-Host "`n  Targeting-Gruppen im Einsatz:"
$Results | Where-Object { $_.TargetGroup } |
    Group-Object TargetGroup |
    Sort-Object Count -Descending |
    ForEach-Object { Write-Host "    $($_.Name): $($_.Count) Server" }

# --- CSV-Export ---
$Results | Export-Csv -Path $OutputCsv -Delimiter ';' -Encoding UTF8 -NoTypeInformation
Write-Host "`nCSV-Export: $OutputCsv" -ForegroundColor Green
