#Requires -Version 5.1
<#
.SYNOPSIS
    Synchronisiert AD-Gruppenmitgliedschaften (CPT_SRV_WSUS-*) mit der
    Zielkonfiguration und weist WSUS-Computergruppen entsprechend zu.

.DESCRIPTION
    NEUE STRATEGIE:
    - W2012R2 + alle DCs -> AD-Gruppe CPT_SRV_WSUS-Servers_NoPatch
                            WSUS-Gruppe Ditzler-NoPatch
                            SuperOps Device-Category: SV_SW-Std_Update-ScanOnly
                            -> KEIN PATCH, weder automatisch noch manuell

    - AutoInstall-Wave1  -> AD-Gruppe CPT_SRV_WSUS-Servers_AutoInstall-Wave1
                            WSUS-Gruppe Ditzler-AutoInstall-Wave1
                            SuperOps Device-Category: SV_SW-Std_Auto-Update-1
                            -> Patches: Anfang Monat, 2./3. Woche, automatisch

    - AutoInstall-Wave2  -> AD-Gruppe CPT_SRV_WSUS-Servers_AutoInstall-Wave2
                            WSUS-Gruppe Ditzler-AutoInstall-Wave2
                            SuperOps Device-Category: SV_SW-Std_Auto-Update-2
                            -> Patches: Ende Monat, 4. Woche, automatisch

    - ManualInstall      -> AD-Gruppe CPT_SRV_WSUS-Servers_ManualInstall
                            WSUS-Gruppe Ditzler-ManualInstall
                            SuperOps Device-Category: SV_SW-Std_Update-ScanOnly
                            -> Scan + Approve auto, Installation via SuperOps-Skript

.PARAMETER Force
    Wirklich ausfuehren (ohne: nur Simulation)

.PARAMETER WsusServer / WsusPort
    WSUS-Verbindungsparameter
#>

param(
    [switch]$Force,
    [string]$WsusServer = 'SV-OS-WSUS-01',
    [int]   $WsusPort   = 8530,
    [bool]  $UseSSL     = $false,
    [string]$Domain     = 'ditzlernet.local'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$DryRun = -not $Force
Import-Module ActiveDirectory -ErrorAction Stop

function Write-Action {
    param([string]$Msg, [string]$Sub = '')
    $Pre = if ($DryRun) { '[SIM]' } else { '[RUN]' }
    $Col = if ($DryRun) { 'Yellow' } else { 'Green' }
    Write-Host "$Pre $Msg" -ForegroundColor $Col
    if ($Sub) { Write-Host "       $Sub" -ForegroundColor Gray }
}

if ($DryRun) {
    Write-Host '=== SIMULATION-MODUS === (-Force fuer echte Ausfuehrung)' -ForegroundColor Yellow
    Write-Host ''
}

# =========================================================
# Zuweisung definieren
# Quelle: Export aus Get-ServerConsolidation.ps1 / manuelle Pflege
# =========================================================

# Format: Computername (uppercase) -> @{ AD = '...'; WsusGroup = '...'; SopsCategory = '...' }
$Zuweisung = @{

    # --- KEIN PATCH (W2012R2 + DCs) ---
    # Domain Controllers
    'SV-OS-DC-01'       = @{ Gruppe = 'NoPatch' }
    'SV-OS-DC-02'       = @{ Gruppe = 'NoPatch' }

    # W2012R2 - aus Excel / SuperOps bestaetigen nach Get-ServerConsolidation.ps1
    'SV-APP-03'         = @{ Gruppe = 'NoPatch' }
    'SV-APP-04'         = @{ Gruppe = 'NoPatch' }
    'SV-BI-APP-01'      = @{ Gruppe = 'NoPatch' }
    'SV-BI-DB-01'       = @{ Gruppe = 'NoPatch' }
    'SV-CEE-APP-01'     = @{ Gruppe = 'NoPatch' }
    'SV-CEE-BI-01'      = @{ Gruppe = 'NoPatch' }
    'SV-CEE-DB-01'      = @{ Gruppe = 'NoPatch' }
    'SV-CEE-SOM-01'     = @{ Gruppe = 'NoPatch' }
    'SV-CEE-TST-01'     = @{ Gruppe = 'NoPatch' }
    'SV-CEE-TST-02'     = @{ Gruppe = 'NoPatch' }
    'SV-FILE-02'        = @{ Gruppe = 'NoPatch' }
    'SV-GDSN-APP-01'    = @{ Gruppe = 'NoPatch' }
    'SV-GDSN-APP-02'    = @{ Gruppe = 'NoPatch' }
    'SV-GDSN-DB-01'     = @{ Gruppe = 'NoPatch' }
    'SV-NLQA-APP-01'    = @{ Gruppe = 'NoPatch' }
    'SV-NLQA-DB-01'     = @{ Gruppe = 'NoPatch' }
    'SV-OS-BITST-01'    = @{ Gruppe = 'NoPatch' }
    'SV-OS-BITST-02'    = @{ Gruppe = 'NoPatch' }
    'SV-PRINT-06'       = @{ Gruppe = 'NoPatch' }

    # --- AUTO-INSTALL WAVE 1 (Anfang Monat, 2./3. Woche) ---
    # Unkritische Infra-Server W2019
    'CL-DMZ-01'         = @{ Gruppe = 'Wave1' }
    'CL-DMZ-02'         = @{ Gruppe = 'Wave1' }
    'SV-CEE-TST-01'     = @{ Gruppe = 'NoPatch' }  # W2012 - schon oben
    'SV-OS-ADC-01'      = @{ Gruppe = 'Wave1' }  # AD Connect
    'SV-OS-AV-01'       = @{ Gruppe = 'Wave1' }  # Bitdefender/AV - unkritisch fuer Patch
    'SV-OS-MGT-01'      = @{ Gruppe = 'Wave1' }  # Management
    'SV-OS-PRB-02'      = @{ Gruppe = 'Wave1' }  # PRTG Probe
    'SV-OS-WDS-01'      = @{ Gruppe = 'Wave1' }  # WDS
    'SV-OS-WSUS-01'     = @{ Gruppe = 'Wave1' }  # WSUS selbst
    'SV-OS-UPS-01'      = @{ Gruppe = 'Wave1' }  # UPS Manager
    'SV-PB-PRB-01'      = @{ Gruppe = 'Wave1' }  # PRTG Probe Produktion

    # --- AUTO-INSTALL WAVE 2 (Ende Monat, 4. Woche) ---
    # SQL Cluster - CAU, koordiniert
    'SV-OS-SQLND-01'    = @{ Gruppe = 'Wave2' }
    'SV-OS-SQLND-02'    = @{ Gruppe = 'Wave2' }

    # --- MANUAL INSTALL (via SuperOps-Skript) ---
    # Gruppe 1 - W2016/W2019, 1. Montag nach Patch Tuesday
    'SV-EOTEC-01'       = @{ Gruppe = 'Manual' }
    'SV-OS-PWR-01'      = @{ Gruppe = 'Manual' }

    # Gruppe 2 - W2019, 2. Mittwoch nach Patch Tuesday
    'SV-OS-OIP-01'      = @{ Gruppe = 'Manual' }
    'SV-OS-SAGE-01'     = @{ Gruppe = 'Manual' }
    'SV-OS-TIME-01'     = @{ Gruppe = 'Manual' }

    # Gruppe 3 - W2019, 2. Mittwoch nach Patch Tuesday (Backup/Infra)
    'SV-OS-BAK-01'      = @{ Gruppe = 'Manual' }
    'SV-OS-BAK-03'      = @{ Gruppe = 'Manual' }
    'SV-OS-IH-01'       = @{ Gruppe = 'Manual' }
    'SV-OS-IR-01'       = @{ Gruppe = 'Manual' }
    'SV-OS-NUPRX-01'    = @{ Gruppe = 'Manual' }

    # Gruppe 4 - Grundstoff W2019, 2. Montag nach Patch Tuesday
    'SV-PB-HV-01'       = @{ Gruppe = 'Manual' }
    'SV-PSG-CIM-01'     = @{ Gruppe = 'Manual' }
    'SV-PSG-CIM-02'     = @{ Gruppe = 'Manual' }
    'SV-PSG-DC-01'      = @{ Gruppe = 'Manual' }  # Achtung: DC Grundstoff-Netz, anderer Bereich
    'SV-PSG-HIST-01'    = @{ Gruppe = 'Manual' }

    # Sonstige manuell zu pruefende Server
    'SV-OS-BAK-02'      = @{ Gruppe = 'Manual' }  # Ubuntu - WSUS nicht relevant, trotzdem manuell

    # WSUS selbst patcht sich auto
}

# AD-Gruppen-Mapping
$ADGruppenMap = @{
    NoPatch = 'CPT_SRV_WSUS-Servers_NoPatch'         # neu anlegen falls noetig
    Wave1   = 'CPT_SRV_WSUS-Servers_AutoInstall-Wave1'
    Wave2   = 'CPT_SRV_WSUS-Servers_AutoInstall-Wave2'
    Manual  = 'CPT_SRV_WSUS-Servers_ManualInstall'
}

# WSUS-Gruppen-Mapping
$WsusGruppenMap = @{
    NoPatch = 'Ditzler-NoPatch'
    Wave1   = 'Ditzler-AutoInstall-Wave1'
    Wave2   = 'Ditzler-AutoInstall-Wave2'
    Manual  = 'Ditzler-ManualInstall'
}

# =========================================================
# AD - Gruppe NoPatch erstellen falls nicht vorhanden
# =========================================================
Write-Host "`n--- AD-Gruppen pruefen/erstellen ---" -ForegroundColor Cyan

foreach ($GKey in $ADGruppenMap.Keys) {
    $GName = $ADGruppenMap[$GKey]
    try {
        Get-ADGroup -Identity $GName -ErrorAction Stop | Out-Null
        Write-Host "  Existiert: $GName" -ForegroundColor Gray
    }
    catch {
        Write-Action "AD-Gruppe erstellen: $GName"
        if (-not $DryRun) {
            New-ADGroup -Name $GName `
                -GroupScope Global `
                -GroupCategory Security `
                -Description "WSUS Patch-Gruppe - automatisch erstellt" `
                -Path "OU=Groups,OU=Ditzler,DC=ditzlernet,DC=local"
            # ACHTUNG: OU-Pfad anpassen!
        }
    }
}

# =========================================================
# AD-Mitgliedschaften synchronisieren
# =========================================================
Write-Host "`n--- AD-Mitgliedschaften ---" -ForegroundColor Cyan

# Aktuelle Mitgliedschaften laden
$AktuelleMS = @{}
foreach ($GKey in $ADGruppenMap.Keys) {
    $GName = $ADGruppenMap[$GKey]
    try {
        $Members = Get-ADGroupMember -Identity $GName -ErrorAction SilentlyContinue |
            Where-Object { $_.objectClass -eq 'computer' } |
            Select-Object -ExpandProperty Name
        $AktuelleMS[$GKey] = @($Members | ForEach-Object { $_.ToUpper() })
    }
    catch { $AktuelleMS[$GKey] = @() }
}

# Soll-Mitgliedschaften ermitteln
$SollMS = @{ NoPatch = @(); Wave1 = @(); Wave2 = @(); Manual = @() }
foreach ($Server in $Zuweisung.Keys) {
    $G = $Zuweisung[$Server].Gruppe
    $SollMS[$G] += $Server.ToUpper()
}

# Differenz berechnen und anwenden
foreach ($GKey in @('NoPatch', 'Wave1', 'Wave2', 'Manual')) {
    $GName  = $ADGruppenMap[$GKey]
    $Soll   = $SollMS[$GKey]
    $Ist    = $AktuelleMS[$GKey]

    $HinzuMs = $Soll | Where-Object { $_ -notin $Ist }
    $EntMs   = $Ist  | Where-Object { $_ -notin $Soll }

    if ($HinzuMs.Count -gt 0) {
        Write-Action "Hinzufuegen zu $GName" ($HinzuMs -join ', ')
        if (-not $DryRun) {
            $ComputerObjs = $HinzuMs | ForEach-Object {
                try { Get-ADComputer -Identity $_ -ErrorAction Stop }
                catch { Write-Warning "Computer nicht gefunden: $_"; $null }
            } | Where-Object { $_ }
            if ($ComputerObjs) {
                Add-ADGroupMember -Identity $GName -Members $ComputerObjs
            }
        }
    }

    if ($EntMs.Count -gt 0) {
        Write-Action "Entfernen aus $GName" ($EntMs -join ', ')
        if (-not $DryRun) {
            $ComputerObjs = $EntMs | ForEach-Object {
                try { Get-ADComputer -Identity $_ -ErrorAction Stop }
                catch { $null }
            } | Where-Object { $_ }
            if ($ComputerObjs) {
                Remove-ADGroupMember -Identity $GName -Members $ComputerObjs -Confirm:$false
            }
        }
    }

    if ($HinzuMs.Count -eq 0 -and $EntMs.Count -eq 0) {
        Write-Host "  $GName -> kein Aenderungsbedarf" -ForegroundColor Gray
    }
}

# =========================================================
# WSUS-Computergruppen synchronisieren
# =========================================================
Write-Host "`n--- WSUS-Computerzuweisungen ---" -ForegroundColor Cyan

try {
    try { Import-Module UpdateServices -ErrorAction Stop }
    catch { Add-Type -Path "$env:ProgramFiles\Update Services\Api\Microsoft.UpdateServices.Administration.dll" }

    $Wsus = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer(
        $WsusServer, $UseSSL, $WsusPort
    )

    $WsusGrpObj = @{}
    $Wsus.GetComputerTargetGroups() | ForEach-Object {
        $WsusGrpObj[$_.Name] = $_
    }

    foreach ($Server in $Zuweisung.Keys) {
        $Soll       = $Zuweisung[$Server].Gruppe
        $WsusGName  = $WsusGruppenMap[$Soll]

        if (-not $WsusGrpObj.ContainsKey($WsusGName)) {
            Write-Warning "WSUS-Gruppe nicht gefunden: $WsusGName (Server: $Server) - Set-WsusGroups.ps1 zuerst ausfuehren!"
            continue
        }

        try {
            # Aktuellen WSUS-Computer-Eintrag suchen
            $WsusComputer = $Wsus.SearchComputerTargets($Server) |
                Where-Object { $_.FullDomainName -like "$Server*" } |
                Select-Object -First 1

            if (-not $WsusComputer) {
                Write-Host "  Nicht in WSUS: $Server (noch kein Check-In?)" -ForegroundColor DarkGray
                continue
            }

            # Aktuelle Gruppen des Computers
            $IstGruppen = $WsusComputer.GetComputerTargetGroups() | Select-Object -ExpandProperty Name
            $SollGruppe = $WsusGName

            if ($IstGruppen -contains $SollGruppe) {
                Write-Host "  OK: $Server -> $SollGruppe" -ForegroundColor Gray
            }
            else {
                Write-Action "WSUS: $Server -> $SollGruppe" "(war: $($IstGruppen -join ', '))"
                if (-not $DryRun) {
                    $WsusComputer.SetTargetGroupFromID($WsusGrpObj[$WsusGName].Id)
                }
            }
        }
        catch {
            Write-Warning "  WSUS-Fehler fuer $Server : $($_.Exception.Message)"
        }
    }
}
catch {
    Write-Warning "WSUS nicht erreichbar oder Modul fehlt: $($_.Exception.Message)"
    Write-Warning 'WSUS-Teil uebersprungen.'
}

# =========================================================
# Abschlussbericht
# =========================================================
Write-Host "`n--- Zusammenfassung ---" -ForegroundColor Cyan
foreach ($GKey in @('NoPatch', 'Wave1', 'Wave2', 'Manual')) {
    Write-Host "  $($GKey.PadRight(10)) $($ADGruppenMap[$GKey]) -> $($SollMS[$GKey].Count) Server"
}

if ($DryRun) {
    Write-Host "`nSimulation beendet. Fuer echte Ausfuehrung: -Force" -ForegroundColor Yellow
}
