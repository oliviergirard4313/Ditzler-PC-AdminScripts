#Requires -Version 5.1
<#
.SYNOPSIS
    Listet alle Server aus SuperOps und klassifiziert sie nach Patch-Strategie.
    Kein Excel. Keine Annahmen. Nur Daten aus SuperOps.

.DESCRIPTION
    Ausgabe:
    - Konsole: gruppierte Ubersicht nach Patch-Kategorie
    - CSV: vollstaendige Liste fuer Weiterverarbeitung (Set-PatchGroupMembership.ps1)

    Klassifikation (absteigend Prioritaet):
    1. KEIN_PATCH  - Windows Server 2012 R2 (beliebige Edition)
    2. KEIN_PATCH  - Domaincontroller (platformFamily = "Domain Controller")
    3. KEIN_PATCH  - Assets deren Name auf -DC-* passt (Fallback falls platformFamily fehlt)
    4. WAVE1/WAVE2/MANUAL - laut bestehender SuperOps-DeviceCategory
    5. UNGEKLAERT  - alles andere -> manuelle Zuweisung noetig

    Felder im CSV:
    AssetId, Name, HostName, Platform, PlatformVersion, PlatformFamily,
    Status, PatchStatus, DeviceCategory, LastContact, PatchGruppe, Bemerkung

.PARAMETER ApiKey
    SuperOps API-Key (oder Umgebungsvariable SUPEROPS_API_KEY)

.PARAMETER ApiEndpoint
    EU: https://euapi.superops.ai/msp (Standard)
    US: https://api.superops.ai/msp

.PARAMETER OutputCsv
    Pfad fuer CSV-Export. Standard: .\SuperOps_ServerInventar_<Datum>.csv

.PARAMETER NurServer
    Wenn gesetzt: nur Assets mit platformCategory = SERVER oder platformFamily
    mit "Server" werden ausgegeben. Sonst alle Assets.

.EXAMPLE
    # API-Key aus Env-Variable:
    $env:SUPEROPS_API_KEY = "xxx"
    .\Get-SuperOpsServerInventar.ps1

    # Direkt mit Key:
    .\Get-SuperOpsServerInventar.ps1 -ApiKey "xxx"

    # Nur Server, nach DE formatiert:
    .\Get-SuperOpsServerInventar.ps1 -NurServer
#>

param(
    [string]$ApiKey      = $env:SUPEROPS_API_KEY,
    [string]$ApiEndpoint = 'https://euapi.superops.ai/msp',
    [string]$OutputCsv   = ".\SuperOps_ServerInventar_$(Get-Date -Format 'yyyyMMdd_HHmm').csv",
    [switch]$NurServer
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---------------------------------------------------------
# Hilfsfunktionen
# ---------------------------------------------------------

function Write-Section {
    param([string]$Titel)
    Write-Host ''
    Write-Host "=== $Titel ===" -ForegroundColor Cyan
}

function Write-Log {
    param([string]$Msg, [string]$Level = 'INFO')
    $Farbe = switch ($Level) {
        'OK'   { 'Green'  }
        'WARN' { 'Yellow' }
        'ERR'  { 'Red'    }
        default { 'White' }
    }
    Write-Host "[$(Get-Date -Format 'HH:mm:ss')][$Level] $Msg" -ForegroundColor $Farbe
}

function Invoke-SopsQuery {
    # Sendet GraphQL-Abfrage an SuperOps API.
    param(
        [string]$Query,
        [hashtable]$Variables = @{}
    )

    if ([string]::IsNullOrEmpty($ApiKey)) {
        throw 'API-Key fehlt. Parameter -ApiKey oder Env-Variable SUPEROPS_API_KEY setzen.'
    }

    $Body = @{
        query     = $Query
        variables = $Variables
    } | ConvertTo-Json -Depth 10 -Compress

    $Headers = @{
        'Content-Type' = 'application/json'
        'apiKey'       = $ApiKey
    }

    $Response = Invoke-RestMethod `
        -Uri     $ApiEndpoint `
        -Method  Post `
        -Headers $Headers `
        -Body    $Body `
        -TimeoutSec 60

    if ($Response.errors) {
        $Fehler = ($Response.errors | ForEach-Object { $_.message }) -join '; '
        throw "GraphQL-Fehler: $Fehler"
    }

    return $Response.data
}

function Get-AlleAssets {
    # Alle Assets aus SuperOps laden (paginiert, je 100).
    $Query = @'
query getAssetList($input: ListInfoInput!) {
  getAssetList(input: $input) {
    assets {
      assetId
      name
      hostName
      platform
      platformVersion
      platformFamily
      platformCategory
      status
      patchStatus
      lastCommunicatedTime
      lastReportedTime
      deviceCategory
    }
    listInfo {
      totalCount
      page
      pageSize
    }
  }
}
'@

    $Alle     = [System.Collections.Generic.List[object]]::new()
    $Seite    = 1
    $ProSeite = 100

    do {
        $Vars = @{
            input = @{
                page     = $Seite
                pageSize = $ProSeite
            }
        }

        $Daten = Invoke-SopsQuery -Query $Query -Variables $Vars
        $Total = $Daten.getAssetList.listInfo.totalCount

        foreach ($Asset in $Daten.getAssetList.assets) {
            $Alle.Add($Asset)
        }

        Write-Log "  Seite $Seite geladen: $($Alle.Count) / $Total Assets"
        $Seite++

    } while (($Seite - 1) * $ProSeite -lt $Total)

    return $Alle
}

function Get-BereinigtesOS {
    # Gibt vereinfachte OS-Bezeichnung zurueck (nur Windows Server relevant).
    param([string]$Platform)

    if ([string]::IsNullOrEmpty($Platform)) { return 'Unbekannt' }

    # Reihenfolge wichtig: spezifischeres zuerst
    if ($Platform -like '*2012 R2*') { return 'WS2012R2' }
    if ($Platform -like '*2012*')    { return 'WS2012'   }
    if ($Platform -like '*2016*')    { return 'WS2016'   }
    if ($Platform -like '*2019*')    { return 'WS2019'   }
    if ($Platform -like '*2022*')    { return 'WS2022'   }
    if ($Platform -like '*2025*')    { return 'WS2025'   }
    if ($Platform -like '*Ubuntu*')  { return 'Ubuntu'   }
    if ($Platform -like '*Linux*')   { return 'Linux'    }
    if ($Platform -like '*Windows 10*') { return 'W10'   }
    if ($Platform -like '*Windows 11*') { return 'W11'   }

    return $Platform
}

function Get-PatchGruppe {
    # Bestimmt Patch-Gruppe aufgrund von OS, platformFamily und Name.
    param(
        [string]$OS,
        [string]$PlatformFamily,
        [string]$Name,
        [string]$DevCatName
    )

    # Regel 1: W2012R2 -> niemals patchen
    if ($OS -eq 'WS2012R2') {
        return 'KEIN_PATCH'
    }

    # Regel 2: Domaincontroller (SuperOps platformFamily)
    if ($PlatformFamily -like '*Domain Controller*') {
        return 'KEIN_PATCH'
    }

    # Regel 3: Name-Muster als Fallback fuer DC-Erkennung
    # Muster: SV-OS-DC-xx oder SV-PSG-DC-xx etc.
    if ($Name -match '-DC-\d+$' -or $Name -match '-DC\d+$') {
        return 'KEIN_PATCH'
    }

    # Regel 4: Bestehende SuperOps-Kategorie auswerten
    if (-not [string]::IsNullOrEmpty($DevCatName)) {
        if ($DevCatName -like '*Auto-Update-1*' -or $DevCatName -like '*Wave1*') {
            return 'WAVE1_AUTO'
        }
        if ($DevCatName -like '*Auto-Update-2*' -or $DevCatName -like '*Wave2*') {
            return 'WAVE2_AUTO'
        }
        if ($DevCatName -like '*Manual*' -or $DevCatName -like '*ScanOnly*') {
            return 'MANUAL'
        }
    }

    # Regel 5: Alles andere -> Zuweisung fehlt
    return 'UNGEKLAERT'
}

# ---------------------------------------------------------
# Hauptprogramm
# ---------------------------------------------------------

Write-Section 'SuperOps Server-Inventar'
Write-Log "Endpunkt: $ApiEndpoint"

# Alle Assets laden
Write-Log 'Lade alle Assets aus SuperOps...'
$AlleAssets = Get-AlleAssets

Write-Log "$($AlleAssets.Count) Assets total geladen." -Level 'OK'

# Filter: nur Server-artige Assets
if ($NurServer) {
    $Assets = $AlleAssets | Where-Object {
        $_.platformCategory -eq 'SERVER' -or
        $_.platformFamily   -like '*Server*' -or
        $_.platform         -like '*Server*'
    }
    Write-Log "Nach Server-Filter: $($Assets.Count) Assets."
} else {
    $Assets = $AlleAssets
}

# ---------------------------------------------------------
# Klassifikation + Ausgabe-Objekte bauen
# ---------------------------------------------------------

$Ergebnis = [System.Collections.Generic.List[PSCustomObject]]::new()

foreach ($Asset in $Assets) {

    # DeviceCategory ist JSON-Objekt in der API-Antwort
    $DevCatName = ''
    if ($Asset.deviceCategory -and $Asset.deviceCategory.name) {
        $DevCatName = $Asset.deviceCategory.name
    }

    $OSEinfach   = Get-BereinigtesOS -Platform $Asset.platform
    $PatchGruppe = Get-PatchGruppe `
        -OS             $OSEinfach `
        -PlatformFamily $Asset.platformFamily `
        -Name           $Asset.name `
        -DevCatName     $DevCatName

    # Bemerkung aufbauen
    $Bemerkung = ''
    if ($PatchGruppe -eq 'KEIN_PATCH') {
        if ($OSEinfach -eq 'WS2012R2') {
            $Bemerkung = 'W2012R2 - kein Patch'
        } elseif ($Asset.platformFamily -like '*Domain Controller*') {
            $Bemerkung = 'DC (platformFamily) - kein Patch'
        } else {
            $Bemerkung = 'DC (Name-Muster) - kein Patch - PRUEFEN'
        }
    } elseif ($PatchGruppe -eq 'UNGEKLAERT') {
        $Bemerkung = 'Keine DeviceCategory - Zuweisung erforderlich'
    }

    # Letzter Kontakt leserlich machen
    $LetzterKontakt = ''
    if (-not [string]::IsNullOrEmpty($Asset.lastCommunicatedTime)) {
        try {
            $LetzterKontakt = [datetime]::Parse($Asset.lastCommunicatedTime).ToString('yyyy-MM-dd HH:mm')
        } catch {
            $LetzterKontakt = $Asset.lastCommunicatedTime
        }
    }

    $Ergebnis.Add([PSCustomObject]@{
        AssetId        = $Asset.assetId
        Name           = $Asset.name
        HostName       = $Asset.hostName
        OS             = $OSEinfach
        Platform       = $Asset.platform
        PlatformFamily = $Asset.platformFamily
        PlatformCat    = $Asset.platformCategory
        OnlineStatus   = $Asset.status
        PatchStatus    = $Asset.patchStatus
        DeviceCategory = $DevCatName
        LetzterKontakt = $LetzterKontakt
        PatchGruppe    = $PatchGruppe
        Bemerkung      = $Bemerkung
    })
}

# ---------------------------------------------------------
# Konsolenausgabe nach Gruppe
# ---------------------------------------------------------

Write-Section 'KEIN_PATCH (W2012R2 + Domaincontroller)'
$GruppeNoPatch = $Ergebnis | Where-Object { $_.PatchGruppe -eq 'KEIN_PATCH' } |
    Sort-Object OS, Name
if ($GruppeNoPatch) {
    $GruppeNoPatch | Format-Table Name, OS, OnlineStatus, PatchStatus, Bemerkung -AutoSize
} else {
    Write-Host '  (keine)' -ForegroundColor Gray
}

Write-Section 'WAVE1_AUTO (Auto-Update Anfang Monat)'
$GruppeW1 = $Ergebnis | Where-Object { $_.PatchGruppe -eq 'WAVE1_AUTO' } | Sort-Object Name
if ($GruppeW1) {
    $GruppeW1 | Format-Table Name, OS, OnlineStatus, PatchStatus, DeviceCategory -AutoSize
} else {
    Write-Host '  (keine)' -ForegroundColor Gray
}

Write-Section 'WAVE2_AUTO (Auto-Update Ende Monat)'
$GruppeW2 = $Ergebnis | Where-Object { $_.PatchGruppe -eq 'WAVE2_AUTO' } | Sort-Object Name
if ($GruppeW2) {
    $GruppeW2 | Format-Table Name, OS, OnlineStatus, PatchStatus, DeviceCategory -AutoSize
} else {
    Write-Host '  (keine)' -ForegroundColor Gray
}

Write-Section 'MANUAL (ScanOnly - Installation via Skript)'
$GruppeM = $Ergebnis | Where-Object { $_.PatchGruppe -eq 'MANUAL' } | Sort-Object Name
if ($GruppeM) {
    $GruppeM | Format-Table Name, OS, OnlineStatus, PatchStatus, DeviceCategory -AutoSize
} else {
    Write-Host '  (keine)' -ForegroundColor Gray
}

Write-Section 'UNGEKLAERT (Zuweisung fehlt - Handlungsbedarf)'
$GruppeU = $Ergebnis | Where-Object { $_.PatchGruppe -eq 'UNGEKLAERT' } | Sort-Object Name
if ($GruppeU) {
    $GruppeU | Format-Table Name, OS, PlatformFamily, PlatformCat, OnlineStatus, DeviceCategory -AutoSize
} else {
    Write-Host '  (keine)' -ForegroundColor Green
}

# ---------------------------------------------------------
# Zusammenfassung
# ---------------------------------------------------------

Write-Section 'Zusammenfassung'
Write-Host "  Total Assets ausgewertet : $($Ergebnis.Count)"
Write-Host "  KEIN_PATCH               : $(($Ergebnis | Where-Object { $_.PatchGruppe -eq 'KEIN_PATCH' }).Count)"
Write-Host "  WAVE1_AUTO               : $(($Ergebnis | Where-Object { $_.PatchGruppe -eq 'WAVE1_AUTO' }).Count)"
Write-Host "  WAVE2_AUTO               : $(($Ergebnis | Where-Object { $_.PatchGruppe -eq 'WAVE2_AUTO' }).Count)"
Write-Host "  MANUAL                   : $(($Ergebnis | Where-Object { $_.PatchGruppe -eq 'MANUAL' }).Count)"
Write-Host "  UNGEKLAERT               : $(($Ergebnis | Where-Object { $_.PatchGruppe -eq 'UNGEKLAERT' }).Count)" `
    -ForegroundColor $(if (($Ergebnis | Where-Object { $_.PatchGruppe -eq 'UNGEKLAERT' }).Count -gt 0) { 'Yellow' } else { 'Green' })

Write-Host ''
Write-Host '  OS-Verteilung:'
$Ergebnis | Group-Object OS | Sort-Object Count -Descending | ForEach-Object {
    Write-Host "    $($_.Name.PadRight(12)) $($_.Count)"
}

# ---------------------------------------------------------
# CSV-Export
# ---------------------------------------------------------

$Ergebnis | Export-Csv -Path $OutputCsv -Delimiter ';' -Encoding UTF8 -NoTypeInformation
Write-Log "CSV gespeichert: $OutputCsv" -Level 'OK'
Write-Log 'Naechster Schritt: CSV pruefen, dann Set-PatchGroupMembership.ps1 -CsvInput <Pfad> -Force' -Level 'OK'
